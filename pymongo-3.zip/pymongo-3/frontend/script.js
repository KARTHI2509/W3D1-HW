let form = document.getElementById("functionForm");

// POST: Add a function/participant
let btn = document.getElementById("addButton");
btn.addEventListener("click", function (event) {

    event.preventDefault();

    let data = {
        participant_id: Number(document.getElementById("participant_id").value),
        full_name: document.getElementById("full_name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        college: document.getElementById("college").value,
        event_name: document.getElementById("event_name").value,
        registration_fee: Number(document.getElementById("registration_fee").value)
    };

    fetch("http://127.0.0.1:8010/functions/add/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        console.log("Success:", data);
        alert(data.message);
        form.reset();
    })
    .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred while adding the participant.");
    });
});


// GET: View all participants
let getBtn = document.getElementById("viewButton");

getBtn.addEventListener("click", function (event) {

    event.preventDefault();

    fetch("http://127.0.0.1:8010/functions/")
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
    .catch(error => console.error(error));

});


// PUT: Update participant
let updateBtn = document.getElementById("updateButton");

updateBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let functionId = document.getElementById("participant_id").value;
    let data = {
        participant_id: Number(document.getElementById("participant_id").value),
        full_name: document.getElementById("full_name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        college: document.getElementById("college").value,
        event_name: document.getElementById("event_name").value,
        registration_fee: Number(document.getElementById("registration_fee").value)
    };

    fetch(`http://127.0.0.1:8010/functions/${functionId}/`, {

        method: "PUT",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(data)

    })

    .then(response => response.json())

    .then(data => {

        console.log("Success:", data);

        alert(data.message);

        form.reset();

    })

    .catch((error) => {

        console.error("Error:", error);

        alert("An error occurred while updating the participant.");

    });

});


// DELETE: Delete participant

let deleteBtn = document.getElementById("deleteButton");

deleteBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let functionId = document.getElementById("participant_id").value;

    fetch(`http://127.0.0.1:8010/functions/${functionId}/delete/`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        alert(data.message);
        form.reset();
    })
    .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred while deleting the participant.");
    });

});
from django.contrib import admin
from django.urls import path
from function import views as function_views

urlpatterns = [
    path("admin/", admin.site.urls),

    # GET
    path("functions/", function_views.get_functions),

    # POST
    path("functions/add/", function_views.add_function),

    # DELETE (Put this BEFORE update)
    path("functions/<int:function_id>/delete/", function_views.delete_function),

    # PUT
    path("functions/<int:function_id>/", function_views.update_function),
]
import json
from bson import ObjectId
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .db import function_collection


# GET : View All Participants
def get_functions(request):
    if request.method == "GET":

        participants = []

        for participant in function_collection.find():
            participant["_id"] = str(participant["_id"])
            participants.append(participant)

        return JsonResponse(participants, safe=False)

    return JsonResponse({"error": "Only GET method allowed"}, status=405)


# POST : Register Participant
@csrf_exempt
def add_function(request):

    if request.method != "POST":
        return JsonResponse({"error": "Only POST method allowed"}, status=405)

    try:

        data = json.loads(request.body)

        result = function_collection.insert_one(data)

        return JsonResponse({
            "message": "Participant Registered Successfully",
            "inserted_id": str(result.inserted_id)
        })

    except Exception as e:

        return JsonResponse({"error": str(e)}, status=500)


# PUT : Update Participant
@csrf_exempt
def update_function(request, function_id):

    if request.method != "PUT":
        return JsonResponse({"error": "Only PUT method allowed"}, status=405)

    try:

        data = json.loads(request.body)

        participant = function_collection.find_one(
            {"participant_id": int(function_id)}
        )

        if not participant:
            return JsonResponse(
                {"error": "Participant Not Found"},
                status=404
            )

        function_collection.update_one(
            {"_id": participant["_id"]},
            {"$set": data}
        )

        return JsonResponse({
            "message": "Participant Updated Successfully"
        })

    except Exception as e:

        return JsonResponse({"error": str(e)}, status=500)


# DELETE : Delete Participant
@csrf_exempt
def delete_function(request, function_id):

    if request.method != "DELETE":
        return JsonResponse({"error": "Only DELETE method allowed"}, status=405)

    try:

        participant = function_collection.find_one(
            {"participant_id": int(function_id)}
        )

        if not participant:
            return JsonResponse(
                {"error": "Participant Not Found"},
                status=404
            )

        function_collection.delete_one(
            {"_id": participant["_id"]}
        )

        return JsonResponse({
            "message": "Participant Deleted Successfully"
        })

    except Exception as e:

        return JsonResponse({"error": str(e)}, status=500)
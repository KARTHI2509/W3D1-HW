from pymongo import MongoClient
client = MongoClient('mongodb+srv://karthikthalipineni_db_user1:KARTHI_23t@cluster0.zf5ottl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = client['MITS']
function_collection = db['function'] 


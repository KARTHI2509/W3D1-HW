from django.http import HttpResponse, JsonResponse

def faculty(request):
    return HttpResponse("This is faculty")

def faculty_details(request):
    return HttpResponse("Faculty Details Page")

def faculty_profile(request):
    return HttpResponse("Faculty Profile Page")

def faculty_name(request, name):
    return HttpResponse(f"Faculty Name : {name}")

def facultyresponse(request):
    data = {
        "message": "Welcome to Faculty App"
    }
    return JsonResponse(data)
from django.shortcuts import render

def faculty(request):
    return render(request, "faculty/home.html")
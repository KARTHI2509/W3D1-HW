from django.http import HttpResponse, JsonResponse

def student(request):
    return HttpResponse("This is Student")

def student_details(request):
    return HttpResponse("Student Details Page")

def student_profile(request):
    return HttpResponse("Student Profile Page")

def student_name(request, name):
    return HttpResponse(f"Student Name : {name}")

def studentresponse(request):
    data = {
        "message": "Welcome to Student App"
    }
    return JsonResponse(data)
from django.shortcuts import render

def student(request):
    return render(request, "student/home.html")
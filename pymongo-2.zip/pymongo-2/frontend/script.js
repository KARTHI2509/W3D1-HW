let btn = document.getElementById("button");

btn.addEventListener("click", function (event) {

    event.preventDefault();

    let data = {
        book_id: Number(document.getElementById("book_id").value),
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        category: document.getElementById("category").value,
        price: Number(document.getElementById("price").value),
        quantity: Number(document.getElementById("quantity").value),
        publisher: document.getElementById("publisher").value
    };

    fetch("http://127.0.0.1:126/books/add/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
        alert(result.message || result.error);
    });
});

let updateBtn = document.getElementById("updateButton");

updateBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let data = {
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        category: document.getElementById("category").value,
        price: Number(document.getElementById("price").value),       
        quantity: Number(document.getElementById("quantity").value), 
        publisher: document.getElementById("publisher").value
    };

    let bookId = document.getElementById("book_id").value; 

    fetch(`http://127.0.0.1:126/books/update/${bookId}/`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
        alert(result.message || result.error);
    });
});

let deleteBtn = document.getElementById("deleteButton");

deleteBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let bookId = document.getElementById("book_id").value; 

    fetch(`http://127.0.0.1:126/books/delete/${bookId}/`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
        alert(result.message || result.error);
    });
});

let getDetailsBtn = document.getElementById("getDetailsButton");

getDetailsBtn.addEventListener("click", function (event) {

    event.preventDefault();

    fetch("http://127.0.0.1:126/books/")
    .then(response => response.json())
    .then(result => {
        console.log(result);
        
        let container = document.getElementById("booksContainer");
        container.innerHTML = "";
        
        result.forEach(book => {
            let bookDiv = document.createElement("div");
            bookDiv.style.padding = "10px";
            bookDiv.style.borderBottom = "1px solid #ccc";
            
            bookDiv.innerHTML = `
                <strong>Book ID:</strong> ${book.book_id} | 
                <strong>Title:</strong> ${book.title} | 
                <strong>Price:</strong> $${book.price}
            `;
            container.appendChild(bookDiv);
        });
    });
});

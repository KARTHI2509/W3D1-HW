import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from bson.objectid import ObjectId  # Added import for ObjectId
from .db import books_collection    # Changed target to the books collection


def get_books(request):
    if request.method == "GET":      # Fixed: Added missing colon
        books = []
        for book in books_collection.find():
            book["_id"] = str(book["_id"])  # Fixed: Convert ObjectId to string for JSON stability
            books.append(book)
        return JsonResponse(books, safe=False)


@csrf_exempt
def add_book(request):
    if request.method == "POST":
        data = json.loads(request.body)
        if "_id" not in data:
            data["_id"] = ObjectId()  # Updated: Uses native MongoDB ObjectId
        else:
            data["_id"] = ObjectId(data["_id"])  # Updated: Uses native MongoDB ObjectId

        try:
            result = books_collection.insert_one(data)
            return JsonResponse(
                {
                    "message": "Book added successfully",
                    "inserted_id": str(result.inserted_id),  # Fixed: Convert ObjectId to string
                }
            )
        except Exception as e:
            return JsonResponse(
                {"error": f"ID already exists: {str(e)}"}, status=400
            )
    return JsonResponse({"error": "Invalid request method"}, status=400)


@csrf_exempt
def update_book(request, id):
    if request.method == "PUT":
        data = json.loads(request.body)

        # FIX: Query using the numerical book_id cast to an Integer instead of ObjectId
        result = books_collection.update_one({"book_id": int(id)}, {"$set": data})

        if result.modified_count > 0:
            return JsonResponse({"message": "Book updated successfully"})
        return JsonResponse(
            {"error": "Book not found or no changes made"}, status=404
        )
    return JsonResponse({"error": "Invalid request method"}, status=400)


@csrf_exempt
def delete_book(request, id):
    if request.method == "DELETE":
        # FIX: Query using the numerical book_id cast to an Integer instead of ObjectId
        result = books_collection.delete_one({"book_id": int(id)})

        if result.deleted_count > 0:
            return JsonResponse({"message": "Book deleted successfully"})
        return JsonResponse({"error": "Book not found"}, status=404)
    return JsonResponse({"error": "Invalid request method"}, status=400)

from django.contrib import admin
from django.urls import path
from app import views as myapp_views  # Adjust this import path if needed to match your project directory

urlpatterns = [
    path('admin/', admin.site.urls),
    path('books/', myapp_views.get_books, name='get_books'),
    path('books/add/', myapp_views.add_book, name='add_book'),
    path('books/update/<int:id>/', myapp_views.update_book, name='update_book'),
    path('books/delete/<int:id>/', myapp_views.delete_book, name='delete_book'),
]

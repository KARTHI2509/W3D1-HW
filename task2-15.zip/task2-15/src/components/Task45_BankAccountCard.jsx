import React from 'react';

const BankAccountCard = ({ accountHolder, accountNumber, balance }) => {
  return (
    <div>
      <h2>{accountHolder}</h2>
      <p>Account: {accountNumber}</p>
      <p>Balance: ₹{balance}</p>
      {balance < 1000 && <span>Minimum Balance Warning</span>}
    </div>
  );
};

export default BankAccountCard;

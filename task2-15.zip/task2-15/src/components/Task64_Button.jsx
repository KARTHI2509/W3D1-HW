import React from 'react';

const Button = ({ label, color, size }) => {
  

  return (
    <button>
      {label}
    </button>
  );
};

export default Button;

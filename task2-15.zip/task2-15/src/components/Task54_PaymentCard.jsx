import React from 'react';

const PaymentCard = ({ orderId, amount, paid }) => {
  return (
    <div>
      <h2>Order #{orderId}</h2>
      <p>Amount: ₹{amount}</p>
      {paid ? (
        <span>Paid</span>
      ) : (
        <span>Pending Payment</span>
      )}
    </div>
  );
};

export default PaymentCard;

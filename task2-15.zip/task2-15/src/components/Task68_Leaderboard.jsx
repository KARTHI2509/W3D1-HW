import React from 'react';

const StudentRow = ({ rank, name, score }) => {
  const getBadge = () => {
    switch (rank) {
      case 1: return { label: 'Gold', color: '#ffd700' };
      case 2: return { label: 'Silver', color: '#c0c0c0' };
      case 3: return { label: 'Bronze', color: '#cd7f32' };
      default: return null;
    }
  };

  const badge = getBadge();

  return (
    <div>
      <span>#{rank}</span>
      <span>{name}</span>
      <span>{score}</span>
      {badge && (
        <span>
          {badge.label}
        </span>
      )}
    </div>
  );
};

const Leaderboard = ({ students }) => {
  const sorted = [...students].sort((a, b) => b.score - a.score);

  return (
    <div>
      <h2>Leaderboard</h2>
      <div>
        {sorted.map((student, index) => (
          <StudentRow key={index} rank={index + 1} {...student} />
        ))}
      </div>
    </div>
  );
};

export default Leaderboard;

import React from 'react';

const RestaurantCard = ({ name, cuisine, homeDelivery }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Cuisine: {cuisine}</p>
      {homeDelivery && <span>Home Delivery Available</span>}
    </div>
  );
};

export default RestaurantCard;

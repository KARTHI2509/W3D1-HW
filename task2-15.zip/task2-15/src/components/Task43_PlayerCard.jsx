import React from 'react';

const PlayerCard = ({ name, position, isCaptain }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Position: {position}</p>
      {isCaptain && <span>Captain</span>}
    </div>
  );
};

export default PlayerCard;

import React from 'react';

const StudentCard = ({ name, course, marks }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Course: {course}</p>
      <p>Marks: {marks}%</p>
      {marks > 95 && <span>Scholarship</span>}
    </div>
  );
};

export default StudentCard;

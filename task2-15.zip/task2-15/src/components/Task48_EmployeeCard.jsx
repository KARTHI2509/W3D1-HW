import React from 'react';

const EmployeeCard = ({ name, department, experience }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Department: {department}</p>
      <p>Experience: {experience} years</p>
      {experience > 10 && <span>Promotion Eligible</span>}
    </div>
  );
};

export default EmployeeCard;

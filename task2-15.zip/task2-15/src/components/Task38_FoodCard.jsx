import React from 'react';

const FoodCard = ({ name, isVeg }) => {
  return (
    <div>
      <h2>{name}</h2>
      {isVeg ? (
        <span>Veg</span>
      ) : (
        <span>Non-Veg</span>
      )}
    </div>
  );
};

export default FoodCard;

import React from 'react';

const AlertBox = ({ type, message }) => {
  

  const getIcon = () => {
    switch (type) {
      case 'Success': return '✓';
      case 'Error': return '✕';
      case 'Warning': return '⚠';
      case 'Info': return 'ℹ';
      default: return '•';
    }
  };

  return (
    <div>
      <span>{getIcon()}</span>
      <span>{message}</span>
    </div>
  );
};

export default AlertBox;

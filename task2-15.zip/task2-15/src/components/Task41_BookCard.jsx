import React from 'react';

const BookCard = ({ title, author, quantity }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Author: {author}</p>
      {quantity === 0 ? (
        <span>Out of Stock</span>
      ) : (
        <span>In Stock ({quantity})</span>
      )}
    </div>
  );
};

export default BookCard;

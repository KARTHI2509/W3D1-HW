import React from 'react';

const ProductCard = ({ name, price }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Price: ₹{price}</p>
      {price > 500 && <span>Free Delivery</span>}
    </div>
  );
};

export default ProductCard;

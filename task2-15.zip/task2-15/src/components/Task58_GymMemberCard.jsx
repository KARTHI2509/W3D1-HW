import React from 'react';

const GymMemberCard = ({ name, membershipType, expiryDate }) => {
  const isExpired = new Date(expiryDate) < new Date();

  return (
    <div>
      <h2>{name}</h2>
      <p>Membership: {membershipType}</p>
      <p>Expires: {expiryDate}</p>
      {isExpired && <span>Membership Expired</span>}
    </div>
  );
};

export default GymMemberCard;

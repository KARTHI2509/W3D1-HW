import React from 'react';

const CartItem = ({ name, price, quantity }) => {
  return (
    <div>
      <span>{name}</span>
      <span>₹{price} x {quantity}</span>
      <span>₹{price * quantity}</span>
    </div>
  );
};

const ShoppingCart = ({ items }) => {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div>
      <h2>Shopping Cart</h2>
      <div>
        {items.map((item, index) => (
          <CartItem key={index} {...item} />
        ))}
      </div>
      <div>
        <strong>Total: ₹{total}</strong>
      </div>
      {total > 1000 && <span>Free Shipping</span>}
    </div>
  );
};

export default ShoppingCart;

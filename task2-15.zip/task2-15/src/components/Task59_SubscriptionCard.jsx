import React from 'react';

const SubscriptionCard = ({ plan, startDate, endDate }) => {
  const getStatus = () => {
    const now = new Date();
    const end = new Date(endDate);
    const daysLeft = Math.ceil((end - now) / (1000 * 60 * 60 * 24));

    if (daysLeft < 0) return { label: 'Expired', color: '#dc3545' };
    if (daysLeft <= 30) return { label: 'Renew Soon', color: '#ffc107' };
    return { label: 'Active', color: '#28a745' };
  };

  const status = getStatus();

  return (
    <div>
      <h2>{plan}</h2>
      <p>Start: {startDate}</p>
      <p>End: {endDate}</p>
      <span>
        {status.label}
      </span>
    </div>
  );
};

export default SubscriptionCard;

import React from 'react';

const WeatherCard = ({ city, temperature }) => {
  const getWeatherInfo = () => {
    if (temperature >= 35) return { label: 'Hot', backgroundColor: '#ff6b6b' };
    if (temperature >= 20) return { label: 'Normal', backgroundColor: '#4ecdc4' };
    return { label: 'Cold', backgroundColor: '#74b9ff' };
  };

  const weather = getWeatherInfo();

  return (
    <div>
      <h2>{city}</h2>
      <p>{temperature}°C</p>
      <span>{weather.label}</span>
    </div>
  );
};

export default WeatherCard;

import React from 'react';

const StudentView = ({ user }) => (
  <div>
    <h2>Student Dashboard</h2>
    <p>Welcome, {user.name}</p>
    <div>
      <h3>My Courses</h3>
      <ul>
        <li>React Fundamentals</li>
        <li>Node.js Basics</li>
      </ul>
    </div>
    <div>
      <h3>Assignments</h3>
      <p>Pending: 3</p>
      <p>Completed: 7</p>
    </div>
  </div>
);

const FacultyView = ({ user }) => (
  <div>
    <h2>Faculty Dashboard</h2>
    <p>Welcome, Prof. {user.name}</p>
    <div>
      <h3>Classes Today</h3>
      <ul>
        <li>React - 10:00 AM</li>
        <li>Node.js - 2:00 PM</li>
      </ul>
    </div>
    <div>
      <h3>Pending Evaluations</h3>
      <p>12 papers to grade</p>
    </div>
  </div>
);

const AdminView = ({ user }) => (
  <div>
    <h2>Admin Dashboard</h2>
    <p>Welcome, {user.name}</p>
    <div>
      <h3>System Overview</h3>
      <p>Total Students: 500</p>
      <p>Total Faculty: 50</p>
      <p>Active Courses: 25</p>
    </div>
    <div>
      <h3>Recent Activity</h3>
      <p>5 new enrollments today</p>
    </div>
  </div>
);

const TrainerView = ({ user }) => (
  <div>
    <h2>Trainer Dashboard</h2>
    <p>Welcome, {user.name}</p>
    <div>
      <h3>Workshops</h3>
      <ul>
        <li>React Workshop - 20 attendees</li>
        <li>Python Bootcamp - 15 attendees</li>
      </ul>
    </div>
    <div>
      <h3>Feedback</h3>
      <p>Average Rating: 4.8/5</p>
    </div>
  </div>
);

const MultiRoleDashboard = ({ user }) => {
  const renderView = () => {
    switch (user.role) {
      case 'Student':
        return <StudentView user={user} />;
      case 'Faculty':
        return <FacultyView user={user} />;
      case 'Admin':
        return <AdminView user={user} />;
      case 'Trainer':
        return <TrainerView user={user} />;
      default:
        return <div>Unknown role</div>;
    }
  };

  return (
    <div>
      <h1>Multi-Role Dashboard</h1>
      {renderView()}
    </div>
  );
};

export default MultiRoleDashboard;

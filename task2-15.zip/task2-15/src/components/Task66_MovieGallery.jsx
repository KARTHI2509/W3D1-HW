import React from 'react';

const MovieCard = ({ title, genre, year, rating }) => {
  const getLabels = () => {
    const labels = [];
    if (rating >= 8) labels.push({ text: 'Trending', color: '#e74c3c' });
    if (new Date().getFullYear() - year <= 1) labels.push({ text: 'New Release', color: '#3498db' });
    if (rating >= 9) labels.push({ text: 'Top Rated', color: '#f39c12' });
    return labels;
  };

  const labels = getLabels();

  return (
    <div>
      <h3>{title}</h3>
      <p>Genre: {genre}</p>
      <p>Year: {year}</p>
      <p>Rating: {rating}/10</p>
      <div>
        {labels.map((label, index) => (
          <span key={index}>
            {label.text}
          </span>
        ))}
      </div>
    </div>
  );
};

const MovieGallery = ({ movies }) => {
  return (
    <div>
      <h2>Movie Gallery</h2>
      <div>
        {movies.map((movie, index) => (
          <MovieCard key={index} {...movie} />
        ))}
      </div>
    </div>
  );
};

export default MovieGallery;

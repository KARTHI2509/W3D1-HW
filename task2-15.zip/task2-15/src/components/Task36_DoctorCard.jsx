import React from 'react';

const DoctorCard = ({ name, specialization, availableToday }) => {
  return (
    <div>
      <h2>Dr. {name}</h2>
      <p>{specialization}</p>
      {availableToday ? (
        <span>Available Today</span>
      ) : (
        <span>Not Available</span>
      )}
    </div>
  );
};

export default DoctorCard;

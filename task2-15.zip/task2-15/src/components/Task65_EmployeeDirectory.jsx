import React from 'react';
import StatusBadge from './Task62_StatusBadge';

const EmployeeCard = ({ name, department, position, status }) => {
  return (
    <div>
      <h3>{name}</h3>
      <p>Department: {department}</p>
      <p>Position: {position}</p>
      <StatusBadge status={status} />
    </div>
  );
};

const EmployeeDirectory = ({ employees }) => {
  return (
    <div>
      <h2>Employee Directory</h2>
      <div>
        {employees.map((emp, index) => (
          <EmployeeCard key={index} {...emp} />
        ))}
      </div>
    </div>
  );
};

export default EmployeeDirectory;

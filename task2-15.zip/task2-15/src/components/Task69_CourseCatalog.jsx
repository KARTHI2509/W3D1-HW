import React from 'react';

const CourseCard = ({ title, instructor, enrollments, seatsLeft, isNew, isPopular }) => {
  return (
    <div>
      <h3>{title}</h3>
      <p>Instructor: {instructor}</p>
      <p>Enrollments: {enrollments}</p>
      <p>Seats Left: {seatsLeft}</p>
      <div>
        {isNew && <span>New Course</span>}
        {isPopular && <span>Popular</span>}
        {seatsLeft <= 10 && seatsLeft > 0 && (
          <span>Limited Seats</span>
        )}
        {seatsLeft === 0 && (
          <span>Full</span>
        )}
      </div>
    </div>
  );
};

const CourseCatalog = ({ courses }) => {
  return (
    <div>
      <h2>Course Catalog</h2>
      <div>
        {courses.map((course, index) => (
          <CourseCard key={index} {...course} />
        ))}
      </div>
    </div>
  );
};

export default CourseCatalog;

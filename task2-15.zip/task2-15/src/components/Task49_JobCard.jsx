import React from 'react';

const JobCard = ({ title, company, vacancies }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Company: {company}</p>
      <p>Vacancies: {vacancies}</p>
      {vacancies > 0 && <span>Actively Hiring</span>}
    </div>
  );
};

export default JobCard;

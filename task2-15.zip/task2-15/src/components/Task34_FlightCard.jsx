import React from 'react';

const FlightCard = ({ airline, flightNumber, seatsAvailable }) => {
  return (
    <div>
      <h2>{airline}</h2>
      <p>Flight: {flightNumber}</p>
      {seatsAvailable > 0 ? (
        <span>Seats Available ({seatsAvailable})</span>
      ) : (
        <span>Fully Booked</span>
      )}
    </div>
  );
};

export default FlightCard;

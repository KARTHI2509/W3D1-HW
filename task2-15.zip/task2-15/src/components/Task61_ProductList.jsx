import React from 'react';

const ProductList = ({ products }) => {
  return (
    <div>
      <h2>Product List</h2>
      <div>
        {products.map((product, index) => (
          <div key={index}>
            <h3>{product.name}</h3>
            <p>Price: ₹{product.price}</p>
            <p>Stock: {product.stock}</p>
            <div>
              {product.onSale && <span>Sale</span>}
              {product.stock === 0 && <span>Out of Stock</span>}
              {product.featured && <span>Featured</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;

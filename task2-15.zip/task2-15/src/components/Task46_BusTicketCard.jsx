import React from 'react';

const BusTicketCard = ({ passengerName, route, status }) => {
  

  return (
    <div>
      <h2>{passengerName}</h2>
      <p>Route: {route}</p>
      <span>{status}</span>
    </div>
  );
};

export default BusTicketCard;

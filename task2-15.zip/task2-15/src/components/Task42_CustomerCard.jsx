import React from 'react';

const CustomerCard = ({ name, points }) => {
  const getMembership = () => {
    if (points >= 1000) return { label: 'Gold', color: '#ffd700' };
    if (points >= 500) return { label: 'Silver', color: '#c0c0c0' };
    return { label: 'Bronze', color: '#cd7f32' };
  };

  const membership = getMembership();

  return (
    <div>
      <h2>{name}</h2>
      <p>Points: {points}</p>
      <span>
        {membership.label}
      </span>
    </div>
  );
};

export default CustomerCard;

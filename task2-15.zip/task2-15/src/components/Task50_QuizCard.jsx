import React from 'react';

const QuizCard = ({ title, subject, status }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Subject: {subject}</p>
      {status ? (
        <span>Completed</span>
      ) : (
        <span>Not Attempted</span>
      )}
    </div>
  );
};

export default QuizCard;

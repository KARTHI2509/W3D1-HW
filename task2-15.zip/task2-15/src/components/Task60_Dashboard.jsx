import React from 'react';
import StudentCard from './Task55_StudentCard';
import EmployeeCard from './Task48_EmployeeCard';
import ProductCard from './Task56_ProductCard';
import CourseCard from './Task40_CourseCard';
import MovieCard from './Task39_MovieCard';

const Dashboard = () => {
  return (
    <div>
      <h1>Dashboard</h1>
      <div>
        <StudentCard name="Alice" course="React" marks={97} />
        <EmployeeCard name="Bob" department="IT" experience={12} />
        <ProductCard name="Laptop" price={75000} />
        <CourseCard title="Full Stack Development" instructor="John" enrollments={1500} />
        <MovieCard title="Action Movie" genre="Action" rating="Adult" />
      </div>
    </div>
  );
};

export default Dashboard;

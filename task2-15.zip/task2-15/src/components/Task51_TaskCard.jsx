import React from 'react';

const TaskCard = ({ title, description, priority }) => {
  

  return (
    <div>
      <h2>{title}</h2>
      <p>{description}</p>
      <span>{priority} Priority</span>
    </div>
  );
};

export default TaskCard;

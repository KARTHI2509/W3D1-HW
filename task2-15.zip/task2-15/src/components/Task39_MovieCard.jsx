import React from 'react';

const MovieCard = ({ title, genre, rating }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Genre: {genre}</p>
      <p>Rating: {rating}</p>
      {rating === 'Adult' && <span>18+</span>}
    </div>
  );
};

export default MovieCard;

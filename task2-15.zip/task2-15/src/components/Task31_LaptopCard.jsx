import React from 'react';

const LaptopCard = ({ brand, model, ram }) => {
  return (
    <div>
      <h2>{brand} {model}</h2>
      <p>RAM: {ram}GB</p>
      {ram >= 16 && <span>Gaming Laptop</span>}
    </div>
  );
};

export default LaptopCard;

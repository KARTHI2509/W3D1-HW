import React from 'react';

const MedicineCard = ({ name, manufacturer, requiresPrescription }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>By: {manufacturer}</p>
      {requiresPrescription && <span>Prescription Required</span>}
    </div>
  );
};

export default MedicineCard;

import React from 'react';

const NotificationCard = ({ message, type }) => {
  const getIcon = () => {
    switch (type) {
      case 'Success':
        return '✓';
      case 'Warning':
        return '⚠';
      case 'Error':
        return '✕';
      default:
        return 'ℹ';
    }
  };

  

  return (
    <div>
      <span>{getIcon()}</span>
      <p>{message}</p>
    </div>
  );
};

export default NotificationCard;

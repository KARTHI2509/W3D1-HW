import React from 'react';

const HotelCard = ({ name, location, breakfastIncluded }) => {
  return (
    <div>
      <h2>{name}</h2>
      <p>Location: {location}</p>
      {breakfastIncluded && <span>Free Breakfast</span>}
    </div>
  );
};

export default HotelCard;

import React from 'react';

const OrderCard = ({ orderId, product, status }) => {
  

  return (
    <div>
      <h2>Order #{orderId}</h2>
      <p>Product: {product}</p>
      <span>
        {status}
      </span>
    </div>
  );
};

export default OrderCard;

import React from 'react';

const TeacherCard = ({ name, subject, designation }) => {
  return (
    <div>
      <h2>Prof. {name}</h2>
      <p>Subject: {subject}</p>
      <p>Designation: {designation}</p>
      {designation === 'Head of Department' && <span>HOD</span>}
    </div>
  );
};

export default TeacherCard;

import React from 'react';

const MobileCard = ({ brand, model, supports5G }) => {
  return (
    <div>
      <h2>{brand} {model}</h2>
      {supports5G && <span>5G Supported</span>}
    </div>
  );
};

export default MobileCard;

import React from 'react';

const CarCard = ({ brand, model, fuelType }) => {
  return (
    <div>
      <h2>{brand} {model}</h2>
      <p>Fuel: {fuelType}</p>
      {fuelType === 'Electric' && <span>Electric Vehicle</span>}
    </div>
  );
};

export default CarCard;

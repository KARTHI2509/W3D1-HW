import React from 'react';

const CourseCard = ({ title, instructor, enrollments }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Instructor: {instructor}</p>
      <p>Enrollments: {enrollments}</p>
      {enrollments > 1000 && <span>Best Seller</span>}
    </div>
  );
};

export default CourseCard;

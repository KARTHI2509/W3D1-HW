import React from 'react';

// Import all task components
import LaptopCard from './components/Task31_LaptopCard';
import MobileCard from './components/Task32_MobileCard';
import CarCard from './components/Task33_CarCard';
import FlightCard from './components/Task34_FlightCard';
import HotelCard from './components/Task35_HotelCard';
import DoctorCard from './components/Task36_DoctorCard';
import MedicineCard from './components/Task37_MedicineCard';
import FoodCard from './components/Task38_FoodCard';
import MovieCard from './components/Task39_MovieCard';
import CourseCard from './components/Task40_CourseCard';
import BookCard from './components/Task41_BookCard';
import CustomerCard from './components/Task42_CustomerCard';
import PlayerCard from './components/Task43_PlayerCard';
import TeacherCard from './components/Task44_TeacherCard';
import BankAccountCard from './components/Task45_BankAccountCard';
import BusTicketCard from './components/Task46_BusTicketCard';
import OrderCard from './components/Task47_OrderCard';
import EmployeeCard from './components/Task48_EmployeeCard';
import JobCard from './components/Task49_JobCard';
import QuizCard from './components/Task50_QuizCard';
import TaskCard from './components/Task51_TaskCard';
import NotificationCard from './components/Task52_NotificationCard';
import WeatherCard from './components/Task53_WeatherCard';
import PaymentCard from './components/Task54_PaymentCard';
import StudentCard from './components/Task55_StudentCard';
import ProductCard from './components/Task56_ProductCard';
import RestaurantCard from './components/Task57_RestaurantCard';
import GymMemberCard from './components/Task58_GymMemberCard';
import SubscriptionCard from './components/Task59_SubscriptionCard';
import Dashboard from './components/Task60_Dashboard';
import ProductList from './components/Task61_ProductList';
import StatusBadge from './components/Task62_StatusBadge';
import AlertBox from './components/Task63_AlertBox';
import Button from './components/Task64_Button';
import EmployeeDirectory from './components/Task65_EmployeeDirectory';
import MovieGallery from './components/Task66_MovieGallery';
import ShoppingCart from './components/Task67_ShoppingCart';
import Leaderboard from './components/Task68_Leaderboard';
import CourseCatalog from './components/Task69_CourseCatalog';
import MultiRoleDashboard from './components/Task70_MultiRoleDashboard';

const App = () => {
  // Dummy data for task 61 (20 products)
  const products = [
    { name: 'Laptop', price: 80000, stock: 15, onSale: true, featured: true },
    { name: 'Smartphone', price: 45000, stock: 0, onSale: false, featured: true },
    { name: 'Headphones', price: 3000, stock: 50, onSale: true, featured: false },
    { name: 'Keyboard', price: 1500, stock: 0, onSale: true, featured: false },
    { name: 'Mouse', price: 800, stock: 100, onSale: false, featured: false },
    { name: 'Monitor', price: 15000, stock: 5, onSale: false, featured: true },
    { name: 'Tablet', price: 25000, stock: 0, onSale: false, featured: false },
    { name: 'Smartwatch', price: 5000, stock: 12, onSale: true, featured: true },
    { name: 'Camera', price: 60000, stock: 8, onSale: false, featured: true },
    { name: 'Printer', price: 10000, stock: 0, onSale: true, featured: false },
    { name: 'Router', price: 2500, stock: 30, onSale: false, featured: false },
    { name: 'Hard Drive', price: 4000, stock: 40, onSale: true, featured: false },
    { name: 'SSD', price: 6000, stock: 25, onSale: false, featured: true },
    { name: 'USB Hub', price: 1200, stock: 0, onSale: false, featured: false },
    { name: 'Graphics Card', price: 40000, stock: 3, onSale: true, featured: true },
    { name: 'Power Bank', price: 2000, stock: 60, onSale: true, featured: false },
    { name: 'Bluetooth Speaker', price: 3500, stock: 18, onSale: false, featured: false },
    { name: 'Microphone', price: 7000, stock: 0, onSale: true, featured: true },
    { name: 'Desk Lamp', price: 1800, stock: 15, onSale: true, featured: false },
    { name: 'Webcam', price: 4500, stock: 10, onSale: false, featured: true }
  ];

  // Dummy data for task 65
  const employees = [
    { name: 'Alice Smith', department: 'Engineering', position: 'Senior Developer', status: 'Active' },
    { name: 'Bob Jones', department: 'HR', position: 'Recruiter', status: 'Inactive' },
    { name: 'Charlie Brown', department: 'Marketing', position: 'Manager', status: 'Pending' },
    { name: 'Diana Prince', department: 'Design', position: 'Lead Designer', status: 'Active' }
  ];

  // Dummy data for task 66
  const movies = [
    { title: 'The Dark Knight', genre: 'Action', year: 2008, rating: 9.0 },
    { title: 'Interstellar', genre: 'Sci-Fi', year: 2014, rating: 8.6 },
    { title: 'Oppenheimer', genre: 'Biography', year: 2023, rating: 9.3 },
    { title: 'Spider-Man: Beyond', genre: 'Animation', year: 2025, rating: 8.9 },
    { title: 'Some Old Movie', genre: 'Drama', year: 1995, rating: 7.2 }
  ];

  // Dummy data for task 67
  const cartItemsNormal = [
    { name: 'Book', price: 300, quantity: 2 },
    { name: 'Pen', price: 50, quantity: 4 }
  ];
  const cartItemsFreeShipping = [
    { name: 'Shoes', price: 1200, quantity: 1 },
    { name: 'Socks', price: 150, quantity: 2 }
  ];

  // Dummy data for task 68
  const leaderboardStudents = [
    { name: 'Emma', score: 98 },
    { name: 'Liam', score: 95 },
    { name: 'Olivia', score: 92 },
    { name: 'Noah', score: 88 },
    { name: 'Sophia', score: 85 }
  ];

  // Dummy data for task 69
  const courses = [
    { title: 'React Fundamentals', instructor: 'Dr. John', enrollments: 1200, seatsLeft: 0, isNew: true, isPopular: true },
    { title: 'Advanced JavaScript', instructor: 'Prof. Sarah', enrollments: 800, seatsLeft: 5, isNew: false, isPopular: true },
    { title: 'Next.js Bootcamp', instructor: 'Dave', enrollments: 150, seatsLeft: 40, isNew: true, isPopular: false },
    { title: 'CSS Layouts Masterclass', instructor: 'Emma', enrollments: 50, seatsLeft: 100, isNew: false, isPopular: false }
  ];

  return (
    <div>
      <h1>React Practice Tasks (Props & Conditional Rendering)</h1>

      {/* Task 31 */}
      <section>
        <h2>Task 31: LaptopCard</h2>
        <LaptopCard brand="Dell" model="Alienware" ram={16} />
        <LaptopCard brand="HP" model="Pavilion" ram={8} />
      </section>

      {/* Task 32 */}
      <section>
        <h2>Task 32: MobileCard</h2>
        <MobileCard brand="Apple" model="iPhone 15 Pro" supports5G={true} />
        <MobileCard brand="Samsung" model="Galaxy A10" supports5G={false} />
      </section>

      {/* Task 33 */}
      <section>
        <h2>Task 33: CarCard</h2>
        <CarCard brand="Tesla" model="Model Y" fuelType="Electric" />
        <CarCard brand="Toyota" model="Camry" fuelType="Petrol" />
      </section>

      {/* Task 34 */}
      <section>
        <h2>Task 34: FlightCard</h2>
        <FlightCard flightNumber="AI-101" availableSeats={20} />
        <FlightCard flightNumber="AI-102" availableSeats={0} />
      </section>

      {/* Task 35 */}
      <section>
        <h2>Task 35: HotelCard</h2>
        <HotelCard name="Grand Hyatt" breakfastIncluded={true} />
        <HotelCard name="Motel 6" breakfastIncluded={false} />
      </section>

      {/* Task 36 */}
      <section>
        <h2>Task 36: DoctorCard</h2>
        <DoctorCard name="Dr. Smith" available={true} />
        <DoctorCard name="Dr. Doe" available={false} />
      </section>

      {/* Task 37 */}
      <section>
        <h2>Task 37: MedicineCard</h2>
        <MedicineCard name="Aspirin" requiresPrescription={false} />
        <MedicineCard name="Amoxicillin" requiresPrescription={true} />
      </section>

      {/* Task 38 */}
      <section>
        <h2>Task 38: FoodCard</h2>
        <FoodCard name="Paneer Tikka" isVeg={true} />
        <FoodCard name="Chicken Biryani" isVeg={false} />
      </section>

      {/* Task 39 */}
      <section>
        <h2>Task 39: MovieCard</h2>
        <MovieCard title="Inception" rating="PG-13" />
        <MovieCard title="Deadpool" rating="Adult" />
      </section>

      {/* Task 40 */}
      <section>
        <h2>Task 40: CourseCard</h2>
        <CourseCard title="React JS" instructor="John" enrollments={1500} />
        <CourseCard title="Rust Programming" instructor="Alice" enrollments={150} />
      </section>

      {/* Task 41 */}
      <section>
        <h2>Task 41: BookCard</h2>
        <BookCard title="Clean Code" quantity={5} />
        <BookCard title="Design Patterns" quantity={0} />
      </section>

      {/* Task 42 */}
      <section>
        <h2>Task 42: CustomerCard</h2>
        <CustomerCard name="Alice" points={1200} />
        <CustomerCard name="Bob" points={750} />
        <CustomerCard name="Charlie" points={200} />
      </section>

      {/* Task 43 */}
      <section>
        <h2>Task 43: PlayerCard</h2>
        <PlayerCard name="Dhoni" isCaptain={true} />
        <PlayerCard name="Kohli" isCaptain={false} />
      </section>

      {/* Task 44 */}
      <section>
        <h2>Task 44: TeacherCard</h2>
        <TeacherCard name="Dr. Kumar" designation="Head of Department" />
        <TeacherCard name="Mr. Sen" designation="Assistant Professor" />
      </section>

      {/* Task 45 */}
      <section>
        <h2>Task 45: BankAccountCard</h2>
        <BankAccountCard accountNumber="123456789" balance={500} />
        <BankAccountCard accountNumber="987654321" balance={1500} />
      </section>

      {/* Task 46 */}
      <section>
        <h2>Task 46: BusTicketCard</h2>
        <BusTicketCard ticketNumber="T-501" status="Confirmed" />
        <BusTicketCard ticketNumber="T-502" status="Waiting List" />
        <BusTicketCard ticketNumber="T-503" status="Cancelled" />
      </section>

      {/* Task 47 */}
      <section>
        <h2>Task 47: OrderCard</h2>
        <OrderCard orderId="ORD-01" status="Pending" />
        <OrderCard orderId="ORD-02" status="Shipped" />
        <OrderCard orderId="ORD-03" status="Delivered" />
      </section>

      {/* Task 48 */}
      <section>
        <h2>Task 48: EmployeeCard</h2>
        <EmployeeCard name="Alice" experience={12} />
        <EmployeeCard name="Bob" experience={5} />
      </section>

      {/* Task 49 */}
      <section>
        <h2>Task 49: JobCard</h2>
        <JobCard title="Frontend Developer" vacancies={5} />
        <JobCard title="Backend Developer" vacancies={0} />
      </section>

      {/* Task 50 */}
      <section>
        <h2>Task 50: QuizCard</h2>
        <QuizCard title="JavaScript Basics" status="Completed" />
        <QuizCard title="React Advanced" status="Not Attempted" />
      </section>

      {/* Task 51 */}
      <section>
        <h2>Task 51: TaskCard</h2>
        <TaskCard title="Write tests" priority="High" />
        <TaskCard title="Refactor code" priority="Medium" />
        <TaskCard title="Fix typo" priority="Low" />
      </section>

      {/* Task 52 */}
      <section>
        <h2>Task 52: NotificationCard</h2>
        <NotificationCard message="Process completed successfully." type="Success" />
        <NotificationCard message="Disk space running low." type="Warning" />
        <NotificationCard message="Failed to reach server." type="Error" />
      </section>

      {/* Task 53 */}
      <section>
        <h2>Task 53: WeatherCard</h2>
        <WeatherCard city="Mumbai" temperature={42} />
        <WeatherCard city="Delhi" temperature={28} />
        <WeatherCard city="Srinagar" temperature={8} />
      </section>

      {/* Task 54 */}
      <section>
        <h2>Task 54: PaymentCard</h2>
        <PaymentCard transactionId="TXN-01" status="Paid" />
        <PaymentCard transactionId="TXN-02" status="Pending" />
      </section>

      {/* Task 55 */}
      <section>
        <h2>Task 55: StudentCard</h2>
        <StudentCard name="John" marks={98} />
        <StudentCard name="Mary" marks={85} />
      </section>

      {/* Task 56 */}
      <section>
        <h2>Task 56: ProductCard</h2>
        <ProductCard name="Mechanical Keyboard" price={800} />
        <ProductCard name="Mouse Pad" price={200} />
      </section>

      {/* Task 57 */}
      <section>
        <h2>Task 57: RestaurantCard</h2>
        <RestaurantCard name="Pizza Hut" homeDelivery={true} />
        <RestaurantCard name="Local Diner" homeDelivery={false} />
      </section>

      {/* Task 58 */}
      <section>
        <h2>Task 58: GymMemberCard</h2>
        <GymMemberCard name="Bob" expiryDate="2020-12-31" />
        <GymMemberCard name="Alice" expiryDate="2028-12-31" />
      </section>

      {/* Task 59 */}
      <section>
        <h2>Task 59: SubscriptionCard</h2>
        <SubscriptionCard name="Netflix Premium" status="Active" />
        <SubscriptionCard name="Spotify Free" status="Expired" />
        <SubscriptionCard name="YouTube Premium" status="Renew Soon" />
      </section>

      {/* Task 60 */}
      <section>
        <h2>Task 60: Dashboard</h2>
        <Dashboard />
      </section>

      {/* Task 61 */}
      <section>
        <h2>Task 61: ProductList (20 products)</h2>
        <ProductList products={products} />
      </section>

      {/* Task 62 */}
      <section>
        <h2>Task 62: StatusBadge</h2>
        <StatusBadge status="Active" />
        <StatusBadge status="Pending" />
        <StatusBadge status="Error" />
        <StatusBadge status="Inactive" />
      </section>

      {/* Task 63 */}
      <section>
        <h2>Task 63: AlertBox</h2>
        <AlertBox type="Success" message="Process completed successfully!" />
        <AlertBox type="Error" message="Database connection failed!" />
        <AlertBox type="Warning" message="Please save your progress." />
        <AlertBox type="Info" message="Maintenance scheduled tonight." />
      </section>

      {/* Task 64 */}
      <section>
        <h2>Task 64: Button</h2>
        <Button label="Click Me" color="blue" size="large" />
        <Button label="Submit" color="green" size="medium" />
        <Button label="Cancel" color="red" size="small" />
      </section>

      {/* Task 65 */}
      <section>
        <h2>Task 65: EmployeeDirectory</h2>
        <EmployeeDirectory employees={employees} />
      </section>

      {/* Task 66 */}
      <section>
        <h2>Task 66: MovieGallery</h2>
        <MovieGallery movies={movies} />
      </section>

      {/* Task 67 */}
      <section>
        <h2>Task 67: ShoppingCart</h2>
        <h3>Cart 1 (Free Shipping Eligible)</h3>
        <ShoppingCart items={cartItemsFreeShipping} />
        <h3>Cart 2 (No Free Shipping)</h3>
        <ShoppingCart items={cartItemsNormal} />
      </section>

      {/* Task 68 */}
      <section>
        <h2>Task 68: Leaderboard</h2>
        <Leaderboard students={leaderboardStudents} />
      </section>

      {/* Task 69 */}
      <section>
        <h2>Task 69: CourseCatalog</h2>
        <CourseCatalog courses={courses} />
      </section>

      {/* Task 70 */}
      <section>
        <h2>Task 70: MultiRoleDashboard</h2>
        <MultiRoleDashboard user={{ name: 'Alice Smith', role: 'Student' }} />
        <MultiRoleDashboard user={{ name: 'Prof. Bob Jones', role: 'Faculty' }} />
        <MultiRoleDashboard user={{ name: 'Charlie Admin', role: 'Admin' }} />
        <MultiRoleDashboard user={{ name: 'Diana Trainer', role: 'Trainer' }} />
      </section>
    </div>
  );
};

export default App;

import { useState } from 'react';

// useState Tasks
import Task1MarksCalculator from './useState/Task1MarksCalculator';
import Task2EmployeeForm from './useState/Task2EmployeeForm';
import Task3MultipleCounters from './useState/Task3MultipleCounters';
import Task4FavoriteMovies from './useState/Task4FavoriteMovies';
import Task5ExpenseTracker from './useState/Task5ExpenseTracker';

// useEffect Tasks
import Task1APIRefreshCounter from './useEffect/Task1APIRefreshCounter';
import Task2OnlineOfflineDetector from './useEffect/Task2OnlineOfflineDetector';
import Task3ScreenWidthTracker from './useEffect/Task3ScreenWidthTracker';
import Task4RandomQuoteGenerator from './useEffect/Task4RandomQuoteGenerator';
import Task5BackgroundColorChanger from './useEffect/Task5BackgroundColorChanger';

// Event Handling Tasks
import Task1Calculator from './EventHandling/Task1Calculator';
import Task2ColorPicker from './EventHandling/Task2ColorPicker';
import Task3CharacterCounter from './EventHandling/Task3CharacterCounter';
import Task4AgeChecker from './EventHandling/Task4AgeChecker';
import Task5ImageSwitcher from './EventHandling/Task5ImageSwitcher';

// React Router Tasks
import Task1CollegeWebsite from './ReactRouter/Task1CollegeWebsite';
import Task2NestedRoutes from './ReactRouter/Task2NestedRoutes';
import Task3BlogApplication from './ReactRouter/Task3BlogApplication';
import Task4ECommerceRouting from './ReactRouter/Task4ECommerceRouting';
import Task5ProtectedRoutes from './ReactRouter/Task5ProtectedRoutes';

// Navigation Tasks
import Task1QuizApplication from './Navigation/Task1QuizApplication';
import Task2BankingApplication from './Navigation/Task2BankingApplication';
import Task3HospitalManagement from './Navigation/Task3HospitalManagement';
import Task4LearningManagementSystem from './Navigation/Task4LearningManagementSystem';
import Task5FoodOrderingApplication from './Navigation/Task5FoodOrderingApplication';

// Fetch API Tasks
import Task1FetchComments from './FetchAPI/Task1FetchComments';
import Task2FetchAlbums from './FetchAPI/Task2FetchAlbums';
import Task3FetchPhotos from './FetchAPI/Task3FetchPhotos';
import Task4RandomUserAPI from './FetchAPI/Task4RandomUserAPI';
import Task5CountryAPI from './FetchAPI/Task5CountryAPI';

// LocalStorage Tasks
import Task1SaveUsername from './LocalStorage/Task1SaveUsername';
import Task2ThemePersistence from './LocalStorage/Task2ThemePersistence';
import Task3TodoList from './LocalStorage/Task3TodoList';
import Task4NotesApplication from './LocalStorage/Task4NotesApplication';
import Task5ShoppingCart from './LocalStorage/Task5ShoppingCart';

const taskMap = {
  'useState-1': { label: 'useState: Marks Calculator', component: Task1MarksCalculator },
  'useState-2': { label: 'useState: Employee Form', component: Task2EmployeeForm },
  'useState-3': { label: 'useState: Multiple Counters', component: Task3MultipleCounters },
  'useState-4': { label: 'useState: Favorite Movies', component: Task4FavoriteMovies },
  'useState-5': { label: 'useState: Expense Tracker', component: Task5ExpenseTracker },
  'useEffect-1': { label: 'useEffect: API Refresh Counter', component: Task1APIRefreshCounter },
  'useEffect-2': { label: 'useEffect: Online/Offline Detector', component: Task2OnlineOfflineDetector },
  'useEffect-3': { label: 'useEffect: Screen Width Tracker', component: Task3ScreenWidthTracker },
  'useEffect-4': { label: 'useEffect: Random Quote Generator', component: Task4RandomQuoteGenerator },
  'useEffect-5': { label: 'useEffect: Background Color Changer', component: Task5BackgroundColorChanger },
  'event-1': { label: 'Event: Calculator', component: Task1Calculator },
  'event-2': { label: 'Event: Color Picker', component: Task2ColorPicker },
  'event-3': { label: 'Event: Character Counter', component: Task3CharacterCounter },
  'event-4': { label: 'Event: Age Checker', component: Task4AgeChecker },
  'event-5': { label: 'Event: Image Switcher', component: Task5ImageSwitcher },
  'router-1': { label: 'Router: College Website', component: Task1CollegeWebsite },
  'router-2': { label: 'Router: Nested Routes', component: Task2NestedRoutes },
  'router-3': { label: 'Router: Blog Application', component: Task3BlogApplication },
  'router-4': { label: 'Router: E-Commerce Routing', component: Task4ECommerceRouting },
  'router-5': { label: 'Router: Protected Routes', component: Task5ProtectedRoutes },
  'nav-1': { label: 'Navigation: Quiz Application', component: Task1QuizApplication },
  'nav-2': { label: 'Navigation: Banking Application', component: Task2BankingApplication },
  'nav-3': { label: 'Navigation: Hospital Management', component: Task3HospitalManagement },
  'nav-4': { label: 'Navigation: LMS', component: Task4LearningManagementSystem },
  'nav-5': { label: 'Navigation: Food Ordering', component: Task5FoodOrderingApplication },
  'fetch-1': { label: 'Fetch: Comments', component: Task1FetchComments },
  'fetch-2': { label: 'Fetch: Albums', component: Task2FetchAlbums },
  'fetch-3': { label: 'Fetch: Photos', component: Task3FetchPhotos },
  'fetch-4': { label: 'Fetch: Random User', component: Task4RandomUserAPI },
  'fetch-5': { label: 'Fetch: Country API', component: Task5CountryAPI },
  'ls-1': { label: 'LocalStorage: Save Username', component: Task1SaveUsername },
  'ls-2': { label: 'LocalStorage: Theme Persistence', component: Task2ThemePersistence },
  'ls-3': { label: 'LocalStorage: Todo List', component: Task3TodoList },
  'ls-4': { label: 'LocalStorage: Notes App', component: Task4NotesApplication },
  'ls-5': { label: 'LocalStorage: Shopping Cart', component: Task5ShoppingCart },
};

function App() {
  const [activeTask, setActiveTask] = useState(null);
  const ActiveComponent = activeTask ? taskMap[activeTask].component : null;

  const sections = [
    { title: '1. Advanced useState Tasks', keys: ['useState-1', 'useState-2', 'useState-3', 'useState-4', 'useState-5'] },
    { title: '2. Advanced useEffect Tasks', keys: ['useEffect-1', 'useEffect-2', 'useEffect-3', 'useEffect-4', 'useEffect-5'] },
    { title: '3. Event Handling Tasks', keys: ['event-1', 'event-2', 'event-3', 'event-4', 'event-5'] },
    { title: '4. React Router Tasks', keys: ['router-1', 'router-2', 'router-3', 'router-4', 'router-5'] },
    { title: '5. Navigation Tasks', keys: ['nav-1', 'nav-2', 'nav-3', 'nav-4', 'nav-5'] },
    { title: '6. Fetch API Tasks', keys: ['fetch-1', 'fetch-2', 'fetch-3', 'fetch-4', 'fetch-5'] },
    { title: '7. Local Storage Tasks', keys: ['ls-1', 'ls-2', 'ls-3', 'ls-4', 'ls-5'] },
  ];

  return (
    <div>
      <h1>W7S4T2 - React Tasks (35 Total)</h1>
      {!activeTask && (
        <div>
          {sections.map((section) => (
            <div key={section.title}>
              <h2>{section.title}</h2>
              {section.keys.map((key) => (
                <button key={key} onClick={() => setActiveTask(key)}>
                  {taskMap[key].label}
                </button>
              ))}
            </div>
          ))}
        </div>
      )}
      {activeTask && (
        <div>
          <button onClick={() => setActiveTask(null)}>Back to Menu</button>
          <h2>{taskMap[activeTask].label}</h2>
          <ActiveComponent />
        </div>
      )}
    </div>
  );
}

export default App;

import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome to our College Website</p>
    </div>
  );
}

function Departments() {
  return (
    <div>
      <h2>Departments</h2>
      <p>Computer Science, Electronics, Mechanical, Civil</p>
    </div>
  );
}

function Faculty() {
  return (
    <div>
      <h2>Faculty</h2>
      <p>Dr. Smith - CS, Dr. Johnson - Electronics, Dr. Williams - Mechanical</p>
    </div>
  );
}

function Placements() {
  return (
    <div>
      <h2>Placements</h2>
      <p>Top recruiters: Google, Microsoft, Amazon, TCS</p>
    </div>
  );
}

function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      <p>Email: info@college.edu | Phone: 123-456-7890</p>
    </div>
  );
}

export default function Task1CollegeWebsite() {
  return (
    <BrowserRouter>
      <div>
        <nav>
          <Link to="/">Home</Link> | <Link to="/departments">Departments</Link> |{' '}
          <Link to="/faculty">Faculty</Link> | <Link to="/placements">Placements</Link> |{' '}
          <Link to="/contact">Contact</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/departments" element={<Departments />} />
          <Route path="/faculty" element={<Faculty />} />
          <Route path="/placements" element={<Placements />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

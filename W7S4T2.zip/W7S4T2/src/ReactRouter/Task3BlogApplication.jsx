import { BrowserRouter, Routes, Route, Link, useParams } from 'react-router-dom';

const blogs = [
  { id: 1, title: 'Getting Started with React', content: 'React is a JavaScript library for building UIs.' },
  { id: 2, title: 'Understanding Hooks', content: 'Hooks let you use state and lifecycle in functional components.' },
  { id: 3, title: 'React Router Guide', content: 'React Router enables navigation in React apps.' },
];

function Home() {
  return (
    <div>
      <h2>Blog Home</h2>
      <p>Welcome to the blog application</p>
    </div>
  );
}

function Blogs() {
  return (
    <div>
      <h2>All Blogs</h2>
      {blogs.map((blog) => (
        <div key={blog.id}>
          <h3><Link to={`/blog/${blog.id}`}>{blog.title}</Link></h3>
        </div>
      ))}
    </div>
  );
}

function BlogDetails() {
  const { id } = useParams();
  const blog = blogs.find((b) => b.id === Number(id));
  if (!blog) return <p>Blog not found</p>;
  return (
    <div>
      <h2>{blog.title}</h2>
      <p>{blog.content}</p>
      <Link to="/blogs">Back to Blogs</Link>
    </div>
  );
}

export default function Task3BlogApplication() {
  return (
    <BrowserRouter>
      <div>
        <nav>
          <Link to="/">Home</Link> | <Link to="/blogs">Blogs</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blogs" element={<Blogs />} />
          <Route path="/blog/:id" element={<BlogDetails />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

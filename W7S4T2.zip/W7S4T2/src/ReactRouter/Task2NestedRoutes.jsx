import { BrowserRouter, Routes, Route, Link, Outlet } from 'react-router-dom';

function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <nav>
        <Link to="students">Students</Link> | <Link to="faculty">Faculty</Link> |{' '}
        <Link to="reports">Reports</Link>
      </nav>
      <Outlet />
    </div>
  );
}

function Students() {
  return (
    <div>
      <h3>Students</h3>
      <p>Student list: Alice, Bob, Charlie</p>
    </div>
  );
}

function Faculty() {
  return (
    <div>
      <h3>Faculty</h3>
      <p>Faculty list: Dr. Adams, Dr. Baker</p>
    </div>
  );
}

function Reports() {
  return (
    <div>
      <h3>Reports</h3>
      <p>Monthly attendance report, Performance report</p>
    </div>
  );
}

export default function Task2NestedRoutes() {
  return (
    <BrowserRouter>
      <div>
        <h1>Nested Routes Demo</h1>
        <Routes>
          <Route path="/dashboard" element={<Dashboard />}>
            <Route path="students" element={<Students />} />
            <Route path="faculty" element={<Faculty />} />
            <Route path="reports" element={<Reports />} />
          </Route>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

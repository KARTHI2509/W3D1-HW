import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { useState } from 'react';

const products = [
  { id: 1, name: 'Laptop', price: 999 },
  { id: 2, name: 'Phone', price: 699 },
  { id: 3, name: 'Tablet', price: 499 },
  { id: 4, name: 'Headphones', price: 199 },
];

function Products({ cart, setCart }) {
  const addToCart = (product) => {
    setCart([...cart, product]);
  };
  return (
    <div>
      <h2>Products</h2>
      {products.map((p) => (
        <div key={p.id}>
          <p>{p.name} - ${p.price}</p>
          <button onClick={() => addToCart(p)}>Add to Cart</button>
        </div>
      ))}
    </div>
  );
}

function Cart({ cart }) {
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <div>
      <h2>Cart</h2>
      {cart.length === 0 ? <p>Cart is empty</p> : (
        <div>
          {cart.map((item, index) => (
            <p key={index}>{item.name} - ${item.price}</p>
          ))}
          <h3>Total: ${total}</h3>
        </div>
      )}
    </div>
  );
}

function Checkout({ cart, setCart }) {
  const placeOrder = () => {
    alert('Order placed successfully!');
    setCart([]);
  };
  return (
    <div>
      <h2>Checkout</h2>
      <p>Items: {cart.length}</p>
      <button onClick={placeOrder} disabled={cart.length === 0}>Place Order</button>
    </div>
  );
}

function Orders() {
  return (
    <div>
      <h2>Orders</h2>
      <p>No orders yet</p>
    </div>
  );
}

export default function Task4ECommerceRouting() {
  const [cart, setCart] = useState([]);
  return (
    <BrowserRouter>
      <div>
        <nav>
          <Link to="/products">Products</Link> | <Link to="/cart">Cart({cart.length})</Link> |{' '}
          <Link to="/checkout">Checkout</Link> | <Link to="/orders">Orders</Link>
        </nav>
        <Routes>
          <Route path="/products" element={<Products cart={cart} setCart={setCart} />} />
          <Route path="/cart" element={<Cart cart={cart} />} />
          <Route path="/checkout" element={<Checkout cart={cart} setCart={setCart} />} />
          <Route path="/orders" element={<Orders />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

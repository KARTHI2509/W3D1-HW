import { useState, useEffect } from 'react';

export default function Task1FetchComments() {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/comments')
      .then((res) => res.json())
      .then((data) => {
        setComments(data.slice(0, 20));
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div>
      <h2>Comments</h2>
      {comments.map((c) => (
        <div key={c.id}>
          <p><strong>Name:</strong> {c.name}</p>
          <p><strong>Email:</strong> {c.email}</p>
          <p><strong>Comment:</strong> {c.body}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}

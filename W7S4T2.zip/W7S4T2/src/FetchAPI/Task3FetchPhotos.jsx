import { useState, useEffect } from 'react';

export default function Task3FetchPhotos() {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/photos')
      .then((res) => res.json())
      .then((data) => {
        setPhotos(data.slice(0, 20));
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div>
      <h2>Photos</h2>
      <div>
        {photos.map((p) => (
          <div key={p.id}>
            <img src={p.url} alt={p.title} width="150" height="150" />
            <p>{p.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';

export default function Task4RandomUserAPI() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUser = () => {
    setLoading(true);
    fetch('https://randomuser.me/api/')
      .then((res) => res.json())
      .then((data) => {
        setUser(data.results[0]);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchUser();
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div>
      <h2>Random User</h2>
      <img src={user.picture.large} alt="User" width="150" />
      <p><strong>Name:</strong> {user.name.first} {user.name.last}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <button onClick={fetchUser}>Get Another User</button>
    </div>
  );
}

import { useState, useEffect } from 'react';

export default function Task5CountryAPI() {
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('https://restcountries.com/v3.1/all')
      .then((res) => res.json())
      .then((data) => {
        setCountries(data);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading...</p>;

  const filtered = countries.filter((c) =>
    c.name.common.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <h2>Countries</h2>
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search country..."
      />
      <div>
        {filtered.slice(0, 20).map((c) => (
          <div key={c.cca3}>
            <img src={c.flags.png} alt={c.name.common} width="100" />
            <p><strong>Country:</strong> {c.name.common}</p>
            <p><strong>Capital:</strong> {c.capital?.[0] || 'N/A'}</p>
            <p><strong>Population:</strong> {c.population.toLocaleString()}</p>
            <hr />
          </div>
        ))}
      </div>
    </div>
  );
}

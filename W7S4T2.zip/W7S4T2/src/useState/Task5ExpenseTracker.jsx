import { useState } from 'react';

export default function Task5ExpenseTracker() {
  const [expenses, setExpenses] = useState([]);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');

  const addExpense = (e) => {
    e.preventDefault();
    if (name.trim() && amount) {
      setExpenses([...expenses, { name: name.trim(), amount: Number(amount) }]);
      setName('');
      setAmount('');
    }
  };

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  return (
    <div>
      <h2>Expense Tracker</h2>
      <form onSubmit={addExpense}>
        <div>
          <label>Expense Name: </label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>Amount: </label>
          <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        </div>
        <button type="submit">Add Expense</button>
      </form>
      <h3>Total Expenses: ${totalExpenses}</h3>
      <h3>Number of Transactions: {expenses.length}</h3>
      <h3>Expense List:</h3>
      <ul>
        {expenses.map((exp, index) => (
          <li key={index}>{exp.name}: ${exp.amount}</li>
        ))}
      </ul>
    </div>
  );
}

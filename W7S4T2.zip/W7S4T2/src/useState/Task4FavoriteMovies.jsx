import { useState } from 'react';

export default function Task4FavoriteMovies() {
  const [movies, setMovies] = useState([]);
  const [movieName, setMovieName] = useState('');

  const addMovie = () => {
    if (movieName.trim()) {
      setMovies([...movies, movieName.trim()]);
      setMovieName('');
    }
  };

  const removeMovie = (index) => {
    setMovies(movies.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h2>Favorite Movies</h2>
      <div>
        <input
          type="text"
          value={movieName}
          onChange={(e) => setMovieName(e.target.value)}
          placeholder="Enter movie name"
        />
        <button onClick={addMovie}>Add Movie</button>
      </div>
      <h3>Movie List:</h3>
      <ul>
        {movies.map((movie, index) => (
          <li key={index}>
            {movie}
            <button onClick={() => removeMovie(index)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

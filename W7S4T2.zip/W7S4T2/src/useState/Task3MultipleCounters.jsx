import { useState } from 'react';

export default function Task3MultipleCounters() {
  const [count1, setCount1] = useState(0);
  const [count2, setCount2] = useState(0);
  const [count3, setCount3] = useState(0);

  return (
    <div>
      <h2>Multiple Counters</h2>
      <div>
        <h3>Counter 1: {count1}</h3>
        <button onClick={() => setCount1(count1 + 1)}>Increment</button>
        <button onClick={() => setCount1(count1 - 1)}>Decrement</button>
        <button onClick={() => setCount1(0)}>Reset</button>
      </div>
      <div>
        <h3>Counter 2: {count2}</h3>
        <button onClick={() => setCount2(count2 + 1)}>Increment</button>
        <button onClick={() => setCount2(count2 - 1)}>Decrement</button>
        <button onClick={() => setCount2(0)}>Reset</button>
      </div>
      <div>
        <h3>Counter 3: {count3}</h3>
        <button onClick={() => setCount3(count3 + 1)}>Increment</button>
        <button onClick={() => setCount3(count3 - 1)}>Decrement</button>
        <button onClick={() => setCount3(0)}>Reset</button>
      </div>
    </div>
  );
}

import { useState } from 'react';

export default function Task2EmployeeForm() {
  const [name, setName] = useState('');
  const [department, setDepartment] = useState('');
  const [salary, setSalary] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [employee, setEmployee] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    setEmployee({ name, department, salary });
    setSubmitted(true);
  };

  return (
    <div>
      <h2>Employee Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Employee Name: </label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>Department: </label>
          <input type="text" value={department} onChange={(e) => setDepartment(e.target.value)} required />
        </div>
        <div>
          <label>Salary: </label>
          <input type="number" value={salary} onChange={(e) => setSalary(e.target.value)} required />
        </div>
        <button type="submit">Submit</button>
      </form>
      {submitted && employee && (
        <div>
          <h3>Employee Card</h3>
          <p>Name: {employee.name}</p>
          <p>Department: {employee.department}</p>
          <p>Salary: ${employee.salary}</p>
        </div>
      )}
    </div>
  );
}

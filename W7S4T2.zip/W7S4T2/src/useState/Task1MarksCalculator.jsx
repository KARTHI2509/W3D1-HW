import { useState } from 'react';

export default function Task1MarksCalculator() {
  const [math, setMath] = useState(0);
  const [science, setScience] = useState(0);
  const [english, setEnglish] = useState(0);

  const total = math + science + english;
  const average = total / 3;
  const grade = average >= 90 ? 'A' : average >= 80 ? 'B' : average >= 70 ? 'C' : average >= 60 ? 'D' : 'F';

  return (
    <div>
      <h2>Marks Calculator</h2>
      <div>
        <label>Math: </label>
        <input type="number" value={math} onChange={(e) => setMath(Number(e.target.value))} />
      </div>
      <div>
        <label>Science: </label>
        <input type="number" value={science} onChange={(e) => setScience(Number(e.target.value))} />
      </div>
      <div>
        <label>English: </label>
        <input type="number" value={english} onChange={(e) => setEnglish(Number(e.target.value))} />
      </div>
      <h3>Total: {total}</h3>
      <h3>Average: {average.toFixed(2)}</h3>
      <h3>Grade: {grade}</h3>
    </div>
  );
}

import { useState, useEffect } from 'react';

export default function Task5BackgroundColorChanger() {
  const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange', 'pink', 'cyan'];
  const [colorIndex, setColorIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setColorIndex((prev) => (prev + 1) % colors.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    document.body.style.backgroundColor = colors[colorIndex];
    return () => { document.body.style.backgroundColor = ''; };
  }, [colorIndex]);

  return (
    <div>
      <h2>Background Color Changer</h2>
      <p>Current Color: {colors[colorIndex]}</p>
    </div>
  );
}

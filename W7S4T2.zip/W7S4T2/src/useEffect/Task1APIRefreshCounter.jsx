import { useState, useEffect } from 'react';

export default function Task1APIRefreshCounter() {
  const [apiCalls, setApiCalls] = useState(0);
  const [data, setData] = useState(null);

  const fetchAPI = async () => {
    setApiCalls((prev) => prev + 1);
    const res = await fetch('https://jsonplaceholder.typicode.com/posts/1');
    const json = await res.json();
    setData(json);
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  return (
    <div>
      <h2>API Refresh Counter</h2>
      <p>API Calls: {apiCalls}</p>
      <button onClick={fetchAPI}>Fetch API Again</button>
      {data && (
        <div>
          <h3>Last Response:</h3>
          <p>Title: {data.title}</p>
          <p>Body: {data.body}</p>
        </div>
      )}
    </div>
  );
}

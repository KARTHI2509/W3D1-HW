import { useState, useEffect } from 'react';

export default function Task2OnlineOfflineDetector() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div>
      <h2>Online/Offline Detector</h2>
      <p>You are {isOnline ? 'Online' : 'Offline'}</p>
    </div>
  );
}

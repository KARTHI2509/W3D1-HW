import { useState, useEffect } from 'react';

export default function Task3ScreenWidthTracker() {
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => setWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div>
      <h2>Screen Width Tracker</h2>
      <p>Width: {width}px</p>
    </div>
  );
}

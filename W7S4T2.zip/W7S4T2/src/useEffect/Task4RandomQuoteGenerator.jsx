import { useState, useEffect } from 'react';

export default function Task4RandomQuoteGenerator() {
  const [quote, setQuote] = useState('Loading quote...');

  const fetchQuote = async () => {
    const res = await fetch('https://api.quotable.io/random');
    const data = await res.json();
    setQuote(`${data.content} — ${data.author}`);
  };

  useEffect(() => {
    fetchQuote();
    const interval = setInterval(fetchQuote, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <h2>Random Quote Generator</h2>
      <p>"{quote}"</p>
    </div>
  );
}

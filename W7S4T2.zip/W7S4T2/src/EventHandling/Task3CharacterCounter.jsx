import { useState } from 'react';

export default function Task3CharacterCounter() {
  const [text, setText] = useState('');

  return (
    <div>
      <h2>Character Counter</h2>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type something..."
        rows={6}
        cols={50}
      />
      <p>Characters: {text.length}</p>
    </div>
  );
}

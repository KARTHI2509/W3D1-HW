import { useState } from 'react';

export default function Task4AgeChecker() {
  const [age, setAge] = useState('');

  const isEligible = age !== '' && Number(age) >= 18;

  return (
    <div>
      <h2>Age Checker</h2>
      <div>
        <label>Enter your age: </label>
        <input
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          placeholder="Enter age"
        />
      </div>
      {age !== '' && (
        <p>{isEligible ? 'Eligible to Vote' : 'Not Eligible'}</p>
      )}
    </div>
  );
}

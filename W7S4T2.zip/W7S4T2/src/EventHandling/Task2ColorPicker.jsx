import { useState } from 'react';

export default function Task2ColorPicker() {
  const [bgColor, setBgColor] = useState('white');

  return (
    <div style={{ backgroundColor: bgColor, minHeight: '100vh' }}>
      <h2>Color Picker</h2>
      <button onClick={() => setBgColor('red')}>Red</button>
      <button onClick={() => setBgColor('blue')}>Blue</button>
      <button onClick={() => setBgColor('green')}>Green</button>
      <p>Current Color: {bgColor}</p>
    </div>
  );
}

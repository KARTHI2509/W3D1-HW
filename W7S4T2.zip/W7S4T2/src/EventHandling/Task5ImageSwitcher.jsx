import { useState } from 'react';

export default function Task5ImageSwitcher() {
  const images = [
    'https://picsum.photos/seed/img1/400/300',
    'https://picsum.photos/seed/img2/400/300',
    'https://picsum.photos/seed/img3/400/300',
    'https://picsum.photos/seed/img4/400/300',
    'https://picsum.photos/seed/img5/400/300',
  ];
  const [index, setIndex] = useState(0);

  const prev = () => setIndex((index - 1 + images.length) % images.length);
  const next = () => setIndex((index + 1) % images.length);

  return (
    <div>
      <h2>Image Switcher</h2>
      <button onClick={prev}>Previous</button>
      <img src={images[index]} alt={`Slide ${index + 1}`} width="400" height="300" />
      <button onClick={next}>Next</button>
      <p>Image {index + 1} of {images.length}</p>
    </div>
  );
}

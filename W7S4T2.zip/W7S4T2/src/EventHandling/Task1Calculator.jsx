import { useState } from 'react';

export default function Task1Calculator() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const calculate = (op) => {
    const a = parseFloat(num1);
    const b = parseFloat(num2);
    if (isNaN(a) || isNaN(b)) {
      setResult('Please enter valid numbers');
      return;
    }
    switch (op) {
      case '+': setResult(a + b); break;
      case '-': setResult(a - b); break;
      case '*': setResult(a * b); break;
      case '/': setResult(b !== 0 ? a / b : 'Cannot divide by zero'); break;
      default: break;
    }
  };

  return (
    <div>
      <h2>Calculator</h2>
      <div>
        <input type="number" value={num1} onChange={(e) => setNum1(e.target.value)} placeholder="Number 1" />
      </div>
      <div>
        <input type="number" value={num2} onChange={(e) => setNum2(e.target.value)} placeholder="Number 2" />
      </div>
      <div>
        <button onClick={() => calculate('+')}>+</button>
        <button onClick={() => calculate('-')}>-</button>
        <button onClick={() => calculate('*')}>*</button>
        <button onClick={() => calculate('/')}>/</button>
      </div>
      {result !== null && <h3>Result: {result}</h3>}
    </div>
  );
}

import { useState } from 'react';

export default function Task5FoodOrderingApplication() {
  const [page, setPage] = useState('restaurants');
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [cart, setCart] = useState([]);

  const restaurants = [
    { id: 1, name: 'Pizza Palace', rating: 4.5 },
    { id: 2, name: 'Burger Barn', rating: 4.2 },
    { id: 3, name: 'Sushi Station', rating: 4.8 },
  ];

  const menus = {
    1: [
      { id: 1, name: 'Margherita Pizza', price: 12 },
      { id: 2, name: 'Pepperoni Pizza', price: 14 },
      { id: 3, name: 'Garlic Bread', price: 6 },
    ],
    2: [
      { id: 4, name: 'Classic Burger', price: 10 },
      { id: 5, name: 'Cheese Burger', price: 11 },
      { id: 6, name: 'Fries', price: 5 },
    ],
    3: [
      { id: 7, name: 'Salmon Roll', price: 15 },
      { id: 8, name: 'Tuna Roll', price: 14 },
      { id: 9, name: 'Miso Soup', price: 4 },
    ],
  };

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const renderPage = () => {
    switch (page) {
      case 'restaurants':
        return (
          <div>
            <h2>Restaurants</h2>
            {restaurants.map((r) => (
              <div key={r.id}>
                <p>{r.name} - Rating: {r.rating}</p>
                <button onClick={() => { setSelectedRestaurant(r); setPage('menu'); }}>View Menu</button>
              </div>
            ))}
          </div>
        );
      case 'menu':
        return (
          <div>
            <h2>Menu - {selectedRestaurant?.name}</h2>
            {(menus[selectedRestaurant?.id] || []).map((item) => (
              <div key={item.id}>
                <p>{item.name} - ${item.price}</p>
                <button onClick={() => addToCart(item)}>Add to Cart</button>
              </div>
            ))}
            <button onClick={() => setPage('restaurants')}>Back to Restaurants</button>
          </div>
        );
      case 'cart':
        return (
          <div>
            <h2>Cart</h2>
            {cart.length === 0 ? <p>Cart is empty</p> : (
              <div>
                {cart.map((item, index) => (
                  <div key={index}>
                    <p>{item.name} - ${item.price}</p>
                    <button onClick={() => removeFromCart(index)}>Remove</button>
                  </div>
                ))}
                <h3>Total: ${total}</h3>
                <button onClick={() => setPage('payment')}>Proceed to Payment</button>
              </div>
            )}
          </div>
        );
      case 'payment':
        return (
          <div>
            <h2>Payment</h2>
            <p>Total Amount: ${total}</p>
            <button onClick={() => { alert('Order placed successfully!'); setCart([]); setPage('restaurants'); }}>
              Pay Now
            </button>
            <button onClick={() => setPage('cart')}>Back to Cart</button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <nav>
        <button onClick={() => setPage('restaurants')}>Restaurants</button>
        <button onClick={() => setPage('menu')}>Menu</button>
        <button onClick={() => setPage('cart')}>Cart({cart.length})</button>
      </nav>
      {renderPage()}
    </div>
  );
}

import { useState } from 'react';

export default function Task1QuizApplication() {
  const [page, setPage] = useState('login');
  const [username, setUsername] = useState('');
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(0);

  const questions = [
    { id: 1, question: 'What is 2 + 2?', options: ['3', '4', '5', '6'], correct: '4' },
    { id: 2, question: 'Capital of France?', options: ['London', 'Berlin', 'Paris', 'Madrid'], correct: 'Paris' },
    { id: 3, question: 'React is a...?', options: ['Framework', 'Library', 'Language', 'Database'], correct: 'Library' },
  ];

  const handleLogin = (e) => {
    e.preventDefault();
    if (username.trim()) setPage('instructions');
  };

  const handleAnswer = (qId, answer) => {
    setAnswers({ ...answers, [qId]: answer });
  };

  const submitQuiz = () => {
    let s = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correct) s++;
    });
    setScore(s);
    setPage('result');
  };

  if (page === 'login') {
    return (
      <div>
        <h2>Quiz Application - Login</h2>
        <form onSubmit={handleLogin}>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Enter name" />
          <button type="submit">Login</button>
        </form>
      </div>
    );
  }

  if (page === 'instructions') {
    return (
      <div>
        <h2>Instructions</h2>
        <p>Welcome {username}!</p>
        <ul>
          <li>There are {questions.length} questions</li>
          <li>Each question has one correct answer</li>
          <li>No time limit</li>
        </ul>
        <button onClick={() => setPage('quiz')}>Start Quiz</button>
      </div>
    );
  }

  if (page === 'quiz') {
    return (
      <div>
        <h2>Quiz</h2>
        {questions.map((q) => (
          <div key={q.id}>
            <p><strong>{q.question}</strong></p>
            {q.options.map((opt) => (
              <label key={opt}>
                <input
                  type="radio"
                  name={`q${q.id}`}
                  value={opt}
                  checked={answers[q.id] === opt}
                  onChange={() => handleAnswer(q.id, opt)}
                />
                {opt}
              </label>
            ))}
          </div>
        ))}
        <button onClick={submitQuiz}>Submit Quiz</button>
      </div>
    );
  }

  if (page === 'result') {
    return (
      <div>
        <h2>Result</h2>
        <p>Hello {username}!</p>
        <p>Your Score: {score} / {questions.length}</p>
        <p>Percentage: {((score / questions.length) * 100).toFixed(0)}%</p>
        <button onClick={() => { setPage('login'); setAnswers({}); setScore(0); }}>Retake Quiz</button>
      </div>
    );
  }
}

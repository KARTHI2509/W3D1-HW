import { useState } from 'react';

export default function Task4LearningManagementSystem() {
  const [page, setPage] = useState('courses');
  const [courses] = useState([
    { id: 1, title: 'React Basics', duration: '4 weeks', enrolled: true },
    { id: 2, title: 'Advanced JavaScript', duration: '6 weeks', enrolled: true },
    { id: 3, title: 'Python Fundamentals', duration: '5 weeks', enrolled: false },
  ]);
  const [assignments] = useState([
    { id: 1, course: 'React Basics', title: 'Build a Todo App', status: 'Completed' },
    { id: 2, course: 'Advanced JavaScript', title: 'Promise Implementation', status: 'Pending' },
  ]);
  const [progress] = useState([
    { course: 'React Basics', completed: 75 },
    { course: 'Advanced JavaScript', completed: 40 },
  ]);
  const [certificates] = useState([
    { course: 'React Basics', date: '2026-06-15' },
  ]);

  const renderPage = () => {
    switch (page) {
      case 'courses':
        return (
          <div>
            <h2>Courses</h2>
            {courses.map((c) => (
              <div key={c.id}>
                <p>{c.title} - {c.duration} - {c.enrolled ? 'Enrolled' : 'Not Enrolled'}</p>
              </div>
            ))}
          </div>
        );
      case 'assignments':
        return (
          <div>
            <h2>Assignments</h2>
            {assignments.map((a) => (
              <div key={a.id}>
                <p>{a.title} ({a.course}) - {a.status}</p>
              </div>
            ))}
          </div>
        );
      case 'progress':
        return (
          <div>
            <h2>Progress</h2>
            {progress.map((p, i) => (
              <div key={i}>
                <p>{p.course}: {p.completed}%</p>
                <div style={{ width: '200px', height: '20px', border: '1px solid black' }}>
                  <div style={{ width: `${p.completed}%`, height: '100%', backgroundColor: 'green' }}></div>
                </div>
              </div>
            ))}
          </div>
        );
      case 'certificates':
        return (
          <div>
            <h2>Certificates</h2>
            {certificates.length === 0 ? <p>No certificates yet</p> : (
              certificates.map((c, i) => (
                <div key={i}><p>Certificate: {c.course} - Earned on {c.date}</p></div>
              ))
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <nav>
        <button onClick={() => setPage('courses')}>Courses</button>
        <button onClick={() => setPage('assignments')}>Assignments</button>
        <button onClick={() => setPage('progress')}>Progress</button>
        <button onClick={() => setPage('certificates')}>Certificates</button>
      </nav>
      {renderPage()}
    </div>
  );
}

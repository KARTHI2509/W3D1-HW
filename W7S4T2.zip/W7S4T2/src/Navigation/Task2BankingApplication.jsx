import { useState } from 'react';

export default function Task2BankingApplication() {
  const [page, setPage] = useState('dashboard');
  const [balance, setBalance] = useState(10000);
  const [amount, setAmount] = useState('');
  const [transactions, setTransactions] = useState([
    { type: 'Credit', amount: 5000, date: '2026-07-10', note: 'Initial Deposit' },
  ]);

  const addTransaction = (type, amt) => {
    setTransactions([{ type, amount: amt, date: new Date().toISOString().split('T')[0], note: '' }, ...transactions]);
  };

  const handleDeposit = (e) => {
    e.preventDefault();
    const val = Number(amount);
    if (val > 0) {
      setBalance(balance + val);
      addTransaction('Credit', val);
      setAmount('');
      setPage('dashboard');
    }
  };

  const handleWithdraw = (e) => {
    e.preventDefault();
    const val = Number(amount);
    if (val > 0 && val <= balance) {
      setBalance(balance - val);
      addTransaction('Debit', val);
      setAmount('');
      setPage('dashboard');
    }
  };

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return (
          <div>
            <h2>Banking Dashboard</h2>
            <p>Account Balance: ${balance}</p>
          </div>
        );
      case 'deposit':
        return (
          <div>
            <h2>Deposit</h2>
            <form onSubmit={handleDeposit}>
              <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount" />
              <button type="submit">Deposit</button>
            </form>
          </div>
        );
      case 'withdraw':
        return (
          <div>
            <h2>Withdraw</h2>
            <form onSubmit={handleWithdraw}>
              <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount" />
              <button type="submit">Withdraw</button>
            </form>
          </div>
        );
      case 'transactions':
        return (
          <div>
            <h2>Transactions</h2>
            {transactions.length === 0 ? <p>No transactions</p> : (
              <table>
                <thead><tr><th>Type</th><th>Amount</th><th>Date</th></tr></thead>
                <tbody>
                  {transactions.map((t, i) => (
                    <tr key={i}><td>{t.type}</td><td>${t.amount}</td><td>{t.date}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <nav>
        <button onClick={() => setPage('dashboard')}>Dashboard</button>
        <button onClick={() => setPage('deposit')}>Deposit</button>
        <button onClick={() => setPage('withdraw')}>Withdraw</button>
        <button onClick={() => setPage('transactions')}>Transactions</button>
      </nav>
      {renderPage()}
    </div>
  );
}

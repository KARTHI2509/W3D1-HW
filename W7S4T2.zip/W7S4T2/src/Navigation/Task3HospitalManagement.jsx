import { useState } from 'react';

export default function Task3HospitalManagement() {
  const [page, setPage] = useState('patients');
  const [patients] = useState([
    { id: 1, name: 'John Doe', age: 45, disease: 'Fever' },
    { id: 2, name: 'Jane Smith', age: 32, disease: 'Headache' },
  ]);
  const [doctors] = useState([
    { id: 1, name: 'Dr. Smith', specialty: 'General', fee: 500 },
    { id: 2, name: 'Dr. Johnson', specialty: 'Cardiologist', fee: 1000 },
  ]);
  const [appointments] = useState([
    { id: 1, patient: 'John Doe', doctor: 'Dr. Smith', date: '2026-07-20', time: '10:00 AM' },
  ]);
  const [bills] = useState([
    { id: 1, patient: 'John Doe', amount: 1500, status: 'Paid' },
  ]);

  const renderPage = () => {
    switch (page) {
      case 'patients':
        return (
          <div>
            <h2>Patients</h2>
            {patients.map((p) => (
              <div key={p.id}><p>{p.name} - Age: {p.age} - Disease: {p.disease}</p></div>
            ))}
          </div>
        );
      case 'doctors':
        return (
          <div>
            <h2>Doctors</h2>
            {doctors.map((d) => (
              <div key={d.id}><p>{d.name} - {d.specialty} - Fee: ${d.fee}</p></div>
            ))}
          </div>
        );
      case 'appointments':
        return (
          <div>
            <h2>Appointments</h2>
            {appointments.map((a) => (
              <div key={a.id}><p>{a.patient} with {a.doctor} on {a.date} at {a.time}</p></div>
            ))}
          </div>
        );
      case 'billing':
        return (
          <div>
            <h2>Billing</h2>
            {bills.map((b) => (
              <div key={b.id}><p>{b.patient} - ${b.amount} - {b.status}</p></div>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <nav>
        <button onClick={() => setPage('patients')}>Patients</button>
        <button onClick={() => setPage('doctors')}>Doctors</button>
        <button onClick={() => setPage('appointments')}>Appointments</button>
        <button onClick={() => setPage('billing')}>Billing</button>
      </nav>
      {renderPage()}
    </div>
  );
}

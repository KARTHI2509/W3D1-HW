import { useState, useEffect } from 'react';

const allProducts = [
  { id: 1, name: 'Laptop', price: 999 },
  { id: 2, name: 'Phone', price: 699 },
  { id: 3, name: 'Tablet', price: 499 },
  { id: 4, name: 'Headphones', price: 199 },
  { id: 5, name: 'Watch', price: 299 },
];

export default function Task5ShoppingCart() {
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('cart');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div>
      <h2>Shopping Cart</h2>
      <h3>Products</h3>
      {allProducts.map((p) => (
        <div key={p.id}>
          <p>{p.name} - ${p.price}</p>
          <button onClick={() => addToCart(p)}>Add to Cart</button>
        </div>
      ))}
      <h3>Cart ({cart.length} items)</h3>
      {cart.length === 0 ? <p>Cart is empty</p> : (
        <div>
          {cart.map((item, index) => (
            <div key={index}>
              <p>{item.name} - ${item.price}</p>
              <button onClick={() => removeFromCart(index)}>Remove</button>
            </div>
          ))}
          <h3>Total: ${total}</h3>
        </div>
      )}
      <p>Refresh the page - cart will persist!</p>
    </div>
  );
}

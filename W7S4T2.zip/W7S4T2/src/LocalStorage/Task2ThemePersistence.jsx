import { useState, useEffect } from 'react';

export default function Task2ThemePersistence() {
  const [isDark, setIsDark] = useState(() => {
    return localStorage.getItem('theme') === 'dark';
  });

  useEffect(() => {
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    document.body.style.backgroundColor = isDark ? '#333' : '#fff';
    document.body.style.color = isDark ? '#fff' : '#000';
    return () => {
      document.body.style.backgroundColor = '';
      document.body.style.color = '';
    };
  }, [isDark]);

  return (
    <div>
      <h2>Theme Persistence</h2>
      <p>Current Theme: {isDark ? 'Dark' : 'Light'}</p>
      <button onClick={() => setIsDark(!isDark)}>
        Switch to {isDark ? 'Light' : 'Dark'} Mode
      </button>
      <p>Refresh the page - theme will persist!</p>
    </div>
  );
}

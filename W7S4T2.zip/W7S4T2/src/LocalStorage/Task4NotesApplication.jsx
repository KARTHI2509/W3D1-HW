import { useState, useEffect } from 'react';

export default function Task4NotesApplication() {
  const [notes, setNotes] = useState(() => {
    const saved = localStorage.getItem('notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addOrUpdateNote = () => {
    if (title.trim() && content.trim()) {
      if (editId) {
        setNotes(notes.map((n) => (n.id === editId ? { ...n, title, content } : n)));
        setEditId(null);
      } else {
        setNotes([...notes, { id: Date.now(), title, content }]);
      }
      setTitle('');
      setContent('');
    }
  };

  const editNote = (note) => {
    setTitle(note.title);
    setContent(note.content);
    setEditId(note.id);
  };

  const deleteNote = (id) => {
    setNotes(notes.filter((n) => n.id !== id));
    if (editId === id) {
      setEditId(null);
      setTitle('');
      setContent('');
    }
  };

  return (
    <div>
      <h2>Notes Application</h2>
      <div>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Note title"
        />
      </div>
      <div>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Note content"
          rows={4}
          cols={40}
        />
      </div>
      <button onClick={addOrUpdateNote}>{editId ? 'Update Note' : 'Add Note'}</button>
      {editId && <button onClick={() => { setEditId(null); setTitle(''); setContent(''); }}>Cancel</button>}
      <h3>Notes:</h3>
      {notes.length === 0 ? <p>No notes yet</p> : notes.map((note) => (
        <div key={note.id}>
          <h4>{note.title}</h4>
          <p>{note.content}</p>
          <button onClick={() => editNote(note)}>Edit</button>
          <button onClick={() => deleteNote(note.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

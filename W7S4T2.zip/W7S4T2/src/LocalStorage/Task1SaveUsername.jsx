import { useState, useEffect } from 'react';

export default function Task1SaveUsername() {
  const [username, setUsername] = useState(() => {
    return localStorage.getItem('username') || '';
  });

  useEffect(() => {
    localStorage.setItem('username', username);
  }, [username]);

  return (
    <div>
      <h2>Save Username</h2>
      <div>
        <label>Username: </label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Enter username"
        />
      </div>
      <p>Saved Username: {username}</p>
      <p>Refresh the page - your username will persist!</p>
    </div>
  );
}

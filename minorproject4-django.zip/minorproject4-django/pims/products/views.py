from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Product
from .serializers import ProductSerializer

@api_view(['GET'])
def get_products(request):
    products = Product.objects.all()
    serializer = ProductSerializer(products, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def add_product(request):
    serializer = ProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Product added successfully", "data": serializer.data})
    return Response(serializer.errors)

@api_view(['PUT'])
def update_product(request, id):
    try:
        product_obj = Product.objects.get(id=id)
    except Product.DoesNotExist:
        return Response({"error": "Product not found"})
        
    serializer = ProductSerializer(product_obj, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Product updated successfully", "data": serializer.data})
    return Response(serializer.errors)

@api_view(['DELETE'])
def delete_product(request, id):
    try:
        product_obj = Product.objects.get(id=id)
    except Product.DoesNotExist:
        return Response({"error": "Product not found"})
        
    product_obj.delete()
    return Response({"message": "Product deleted successfully"})

import React from 'react'
import StudentCard from './Components/studentCard'
import EmployeeCard from './Components/EmployeeCard'
import ProductCard from './Components/ProductCard'
import MovieCard from './Components/MovieCard'
import BookCard from './Components/BookCard'
import CourseCard from './Components/CourseCard'
import ProfileCard from './Components/ProfileCard'
import CompanyCard from './Components/CompanyCard'
import Button from './Components/Button'
const App = () => {
  const studentsList = [
    { id: 1, name: "Arjun", age: 20, course: "Computer Science" },
    { id: 2, name: "Sneha", age: 21, course: "Data Science" },
    { id: 3, name: "Kabir", age: 22, course: "Cyber Security" }
  ];
  const corporateDetails = {
    name: "Tech Mahindra",
    industry: "IT Services",
    employeeCount: "150,000+",
    headquarters: "Pune, India",
    foundedYear: 1986
  };
  const isLoggedIn=true;
  const isAvailable=true;
  const marks=40;
  const age=20;
  const isPremium=false;
  const discount=10;
  const isOnline=true;
  const isAdmin=true;
  const hour=new Date().getHours();
  const userProfilePic = null; 
  const defaultAvatar = "https://placehold.co";

  return (
    <>
    <div>
      <StudentCard name="karthik" age={22} course="python"/>
      <EmployeeCard name="john" designation="Developer" salary={50000} department="IT"/>
      <EmployeeCard name="jane" designation="Manager" salary={70000} department="HR"/>
      <ProductCard name="Laptop" price={1000} description="A high-performance laptop"/>
      <ProductCard name="Smartphone" price={800} description="A latest model smartphone"/>
      <ProductCard name="Headphones" price={200} description="Noise-cancelling headphones"/>
      <ProductCard name="Smartwatch" price={300} description="A smartwatch with fitness tracking features"/>
      <ProductCard name="Tablet" price={400} description="A lightweight tablet for work and play"/>
      <MovieCard title="Inception" poster="https://m.media-amazon.com/images/I/51s+6Z1J5-L._AC_.jpg" rating={8.8} genre="Sci-Fi"/>
      <BookCard title="The Great Gatsby" author="F. Scott Fitzgerald" price={10.99} category="Classic Literature"/>
      <CourseCard coursename="React for Beginners" trainer="John Doe" duration="4 weeks" fee={1200}/>
      <ProfileCard profileimage="https://example.com/alice.jpg" name="Alice" role="Software Engineer" location="San Francisco"/>
{studentsList.map((student) => (
  <StudentCard 
    key={student.id} 
    name={student.name} 
    age={student.age} 
    course={student.course} 
  />
))}
<CompanyCard company={corporateDetails} />
  <Button label="Submit" onClick={() => alert('Form Submitted!')} />
      <Button label="Cancel" onClick={() => alert('Action Cancelled!')} />
      <Button label="Click Me" onClick={() => alert('Hello!')} />
{isLoggedIn?<p>Login Successful</p>:<p>Please Login</p>}
{isAvailable?<p>Available</p>:<p>Out of Stock</p>}
{marks >= 35 ? 'Pass' : 'Fail'}
{age>=18?<p>Adult</p>:<p>Minor</p>}
{isPremium?<p>Premium User</p>:<p>Regular User</p>}
{discount>0?<p>Discount Available</p>:<p>No Discount</p>}
{isOnline?<p>Online</p>:<p>Offline</p>}
{isAdmin?<p>Admin Access</p>:<p>User Access</p>}
{hour < 12 ? (
  <p>Good Morning</p>
) : hour < 17 ? (
  <p>Good Afternoon</p>
) : (
  <p>Good Evening</p>
)}

{userProfilePic ? (
        <img src={userProfilePic} alt="Custom Profile" />
      ) : (
        <img src={defaultAvatar} alt="Default Avatar" />
      )}
  

<StudentCard name="John Doe" age={20} course="Computer Science" marks={95} />
<EmployeeCard name="Jane Smith" designation="Software Engineer" salary={80000} department="IT" experience={6} />
<MovieCard title="Inception" poster="https://m.media-amazon.com/images/I/51s+6Z1J5-L._AC_.jpg" rating={8.8} genre="Sci-Fi" />
 <ProductCard name="Laptop" price={1200} description="A high-performance laptop" />   
    </div>
    </>
  );
}

export default App


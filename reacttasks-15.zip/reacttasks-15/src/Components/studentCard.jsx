function studentCard({name,age,course,marks}){
    return(
        <div>
            <h1>my name is :{name}</h1>
            <p>Age: {age}</p>
            <p>Course: {course}</p>
            {marks>90?<p>Topper</p>:<p>Average</p>}
        </div>
    )
}

export default studentCard
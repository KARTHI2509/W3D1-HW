function MovieCard({ title, poster,rating, genre }) {
    return (
        <div>
            <h1>Movie Title: {title}</h1>
            <img src={poster} alt={title} />
            <p>Rating: {rating}</p>
            <p>Genre: {genre}</p>
            {rating>8.5?<p>Blockbuster</p>:<p>Average</p>}
        </div>
    )
}
export default MovieCard;
function CourseCard({ coursename,trainer,duration,fee }) {
    return (
        <div >
            <h2>{coursename}</h2>
            <p>Trainer: {trainer}</p>
            <p>Duration: {duration}</p>
            <p>Fee: {fee}</p>
            </div>
    )
}
export default CourseCard;
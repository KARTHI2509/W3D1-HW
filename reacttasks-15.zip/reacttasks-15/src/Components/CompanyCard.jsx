
function CompanyCard({ company }) {
  return (
    <div>
      <h2>{company.name}</h2>
      <p>Industry: {company.industry}</p>
      <p>Employees: {company.employeeCount}</p>
      <p>Headquarters: {company.headquarters}</p>
      <p>Founded: {company.foundedYear}</p>
    </div>
  );
}

export default CompanyCard;

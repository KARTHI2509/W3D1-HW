function ProfileCard({ profileimage,name, role,location }) {
    return (
        <div>
            <img src={profileimage} alt="Profile" />
            <h2>{name}</h2>
            <p>Role: {role}</p>
            <p>Location: {location}</p>
        </div>
    )
}
export default ProfileCard;
function EmployeeCard({name,designation,salary,department,experience}) { 
    return(
        <div>
            <h1>Employee Name: {name}</h1>
            <p>Designation: {designation}</p>
            <p>Salary: {salary}</p>
            <p>Department: {department}</p>
            {experience>5?<p>Senior Employee</p>:<p>Junior Employee</p>}
        </div>
    )
}

export default EmployeeCard

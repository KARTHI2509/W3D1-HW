function BookCard({ title,author,price,category }) {
    return (
        <div>
            <h1>Book Title: {title}</h1>
            <p>Author: {author}</p>
            <p>Price: {price}</p>
            <p>Category: {category}</p>
        </div>
    )

}
export default BookCard;
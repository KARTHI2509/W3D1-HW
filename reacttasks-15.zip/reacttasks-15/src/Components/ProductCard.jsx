function ProductCard({ name ,price,description}) {
    const isonsale=true;
    return (
        <div>
            <h1>Product Name: {name}</h1>
            <p>Price: {price}</p>
            <p>Description: {description}</p>
            {isonsale?<p>SaleBadge</p>:<p>Not on Sale</p>}
        
        </div>
    );
}
export default ProductCard
"""
URL configuration for hms project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from doctor import views as doctor_views
from appointment import views as appointment_views
from patient import views as patient_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('doctors/', doctor_views.doctor_list, name='doctor-list'),
    path('doctors/create/', doctor_views.doctor_create, name='doctor-create'),
    path('doctors/update/<int:id>/', doctor_views.doctor_update, name='doctor-update'),
    path('doctors/delete/<int:id>/', doctor_views.doctor_delete, name='doctor-delete'),
    path('appointments/', appointment_views.appointment_list, name='appointment-list'),
    path('appointments/create/', appointment_views.appointment_create, name='appointment-create'),
    path('appointments/update/<int:id>/', appointment_views.appointment_update, name='appointment-update'),
    path('appointments/delete/<int:id>/', appointment_views.appointment_delete, name='appointment-delete'),
    path('patients/', patient_views.patient_list, name='patient-list'),
    path('patients/create/', patient_views.patient_create, name='patient-create'),
    path('patients/update/<int:id>/', patient_views.patient_update, name='patient-update'),
    path('patients/delete/<int:id>/', patient_views.patient_delete, name='patient-delete'),
    
]

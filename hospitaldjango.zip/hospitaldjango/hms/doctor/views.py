from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Doctor
from .serializers import DoctorSerializer
@api_view(['GET'])
def doctor_list(request):
    doctors = Doctor.objects.all()
    serializer = DoctorSerializer(doctors, many=True)
    return Response(serializer.data)
@api_view(['POST'])
def doctor_create(request):
    serializer = DoctorSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Doctor added successfully","Doctor": serializer.data})
    return Response(serializer.errors)
@api_view(['PUT'])
def doctor_update(request,id):
    doctor_obj = Doctor.objects.get(id=id)
    serializer = DoctorSerializer(doctor_obj, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Doctor updated successfully","Doctor": serializer.data})
    return Response(serializer.errors)
@api_view(['DELETE'])
def doctor_delete(request,id):
    doctor_obj = Doctor.objects.get(id=id)
    doctor_obj.delete()
    return Response({"message": "Doctor deleted successfully"})
# Create your views here.

from rest_framework.decorators import api_view
from rest_framework.response import Response


from .models import appointment
from .serializers import appointmentSerializer
@api_view(['GET'])
def appointment_list(request):
    appointments = appointment.objects.all()
    serializer = appointmentSerializer(appointments, many=True)
    return Response(serializer.data)
@api_view(['POST'])
def appointment_create(request):
    serializer = appointmentSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Appointment added successfully","Appointment": serializer.data})
    return Response(serializer.errors)
@api_view(['PUT'])
def appointment_update(request,id):
    appointment_obj = appointment.objects.get(id=id)
    serializer = appointmentSerializer(appointment_obj, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Appointment updated successfully","Appointment": serializer.data})
    return Response(serializer.errors)
@api_view(['DELETE'])
def appointment_delete(request,id):
    appointment_obj = appointment.objects.get(id=id)
    appointment_obj.delete()
    return Response({"message": "Appointment deleted successfully"})
# Create your views here.

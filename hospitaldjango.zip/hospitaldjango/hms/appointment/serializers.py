from rest_framework import serializers
from .models import appointment
class appointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = appointment
        fields = '__all__'
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import patient
from .serializers import patientSerializer

@api_view(['GET'])
def patient_list(request):
    patients = patient.objects.all()
    serializer = patientSerializer(patients, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def patient_create(request):
    serializer = patientSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({
            "message": "Patient added successfully",
            "Patient": serializer.data
        })
    return Response(serializer.errors)

@api_view(['PUT', 'PATCH'])
def patient_update(request, id):
    try:
        patient_obj = patient.objects.get(id=id)
    except patient.DoesNotExist:
        return Response({"error": "Patient not found"})

    serializer = patientSerializer(patient_obj, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response({
            "message": "Patient updated successfully",
            "Patient": serializer.data
        })
    return Response(serializer.errors)

@api_view(['DELETE'])
def patient_delete(request, id):
    try:
        patient_obj = patient.objects.get(id=id)
    except patient.DoesNotExist:
        return Response({"error": "Patient not found"})

    patient_obj.delete()
    return Response({
        "message": "Patient deleted successfully"
    })

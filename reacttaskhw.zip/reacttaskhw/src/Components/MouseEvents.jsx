import React, { useState } from "react";

const MouseEvents = () => {

  const [message, setMessage] = useState("");

  return (
    <div>
      <h2>Mouse Events</h2>

      <button
        onClick={() => setMessage("Button Clicked")}
        onMouseOver={() => setMessage("Mouse Over")}
        onMouseLeave={() => setMessage("Mouse Left")}
      >
        Move Mouse Here
      </button>

      <h3>{message}</h3>
    </div>
  );
};

export default MouseEvents;
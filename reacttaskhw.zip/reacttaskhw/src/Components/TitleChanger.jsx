import React, { useEffect, useState } from "react";

const TitleChanger = () => {

  const [count, setCount] = useState(1);

  useEffect(() => {
    document.title = `Count : ${count}`;
  }, [count]);

  return (
    <div>
      <h2>Title Changer</h2>

      <h1>{count}</h1>

      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
};

export default TitleChanger;
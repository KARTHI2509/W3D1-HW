import React, { useState } from "react";

const Password = () => {
  const [show, setShow] = useState(false);

  return (
    <div>
      <h2>Password Visibility</h2>

      <input
        type={show ? "text" : "password"}
        placeholder="Enter Password"
      />

      <br /><br />

      <button onClick={() => setShow(!show)}>
        {show ? "Hide Password" : "Show Password"}
      </button>
    </div>
  );
};

export default Password;
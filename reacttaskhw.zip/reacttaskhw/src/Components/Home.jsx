import { useNavigate } from "react-router-dom";

const Home = () => {

  const navigate = useNavigate();

  return (
    <div>
      <h1>Home</h1>

      <button onClick={() => navigate("/add")}>Add Student</button>

      <button onClick={() => navigate("/view")}>View Students</button>
    </div>
  );
};

export default Home;
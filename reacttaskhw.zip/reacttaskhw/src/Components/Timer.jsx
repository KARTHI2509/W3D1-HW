import React, { useEffect, useState } from "react";

const Timer = () => {

  const [count, setCount] = useState(0);

  useEffect(() => {

    if (count === 10) return;

    const timer = setInterval(() => {
      setCount((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);

  }, [count]);

  return (
    <div>
      <h2>Timer</h2>
      <h1>{count}</h1>
    </div>
  );
};

export default Timer;
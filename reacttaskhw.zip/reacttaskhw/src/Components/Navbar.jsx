import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div>
      <Link to="/">Home</Link> |{" "}
      <Link to="/services">Services</Link> |{" "}
      <Link to="/contact">Contact</Link>
      <Link to="/dashboard">Dashboard</Link> |{" "}
      <Link to="/profile">Profile</Link> |{" "}
      <Link to="/settings">Settings</Link>
      <Link to="/student/123">Student</Link>
    </div>
  );
};

export default Navbar;
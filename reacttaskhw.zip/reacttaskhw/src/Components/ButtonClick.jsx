import React, { useState } from "react";

const ButtonClick = () => {

  const [message, setMessage] = useState("");

  return (
    <div>
      <h2>Button Click</h2>

      <button onClick={() => setMessage("Button Clicked")}>
        Click Me
      </button>

      <h3>{message}</h3>
    </div>
  );
};

export default ButtonClick;
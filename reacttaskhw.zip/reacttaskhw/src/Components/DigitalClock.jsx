import React, { useEffect, useState } from "react";

const DigitalClock = () => {

  const [time, setTime] = useState(new Date());

  useEffect(() => {

    const clock = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(clock);

  }, []);

  return (
    <div>
      <h2>Digital Clock</h2>

      <h1>
        {time.getHours()} :
        {time.getMinutes()} :
        {time.getSeconds()}
      </h1>
    </div>
  );
};

export default DigitalClock;
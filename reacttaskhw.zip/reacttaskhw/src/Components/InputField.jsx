import React, { useState } from "react";

const InputField = () => {

  const [name, setName] = useState("");

  return (
    <div>
      <h2>Input Field</h2>

      <input
        type="text"
        placeholder="Enter Name"
        onChange={(e) => setName(e.target.value)}
      />

      <h3>Welcome {name}</h3>
    </div>
  );
};

export default InputField;
import React, { useState } from "react";

const ShoppingCart = () => {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>Shopping Cart</h2>

      <button onClick={() => setCount(count + 1)}>
        Add Laptop
      </button>

      <br /><br />

      <button onClick={() => setCount(count + 1)}>
        Add Mobile
      </button>

      <br /><br />

      <button onClick={() => setCount(count + 1)}>
        Add Keyboard
      </button>

      <h3>Total Items: {count}</h3>
    </div>
  );
};

export default ShoppingCart;
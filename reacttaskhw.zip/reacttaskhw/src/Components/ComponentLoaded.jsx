import React, { useEffect } from "react";

const ComponentLoaded = () => {

  useEffect(() => {
    console.log("Component Loaded");
  }, []);

  return (
    <div>
      <h2>Open Console</h2>
    </div>
  );
};

export default ComponentLoaded;
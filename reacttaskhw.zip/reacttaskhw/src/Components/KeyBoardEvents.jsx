import React, { useState } from "react";

const KeyboardEvents = () => {

  const [key, setKey] = useState("");

  return (
    <div>
      <h2>Keyboard Events</h2>

      <input
        type="text"
        placeholder="Press any key"
        onKeyDown={(e) => setKey(`Key Down: ${e.key}`)}
        onKeyUp={(e) => setKey(`Key Up: ${e.key}`)}
      />

      <h3>{key}</h3>
    </div>
  );
};

export default KeyboardEvents;
import React from 'react';
import Counter from './Components/Counter';
import StudentForm from './Components/StudentForm';
import Theme from './Components/Theme';
import Password from './Components/Password';
import ShoppingCart from './Components/ShoppingCart';
import ComponentLoaded from './Components/ComponentLoaded';
import Timer from './Components/Timer';
import DigitalClock from './Components/DigitalClock';
import FetchUsers from './Components/FetchUsers';
import TitleChanger from './Components/TitleChanger';
import ButtonClick from './Components/ButtonClick';
import InputField from './Components/InputField';
import FormSubmit from './Components/FormSubmit';
import MouseEvents from './Components/MouseEvents';
import KeyBoardEvents from './Components/KeyboardEvents';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './Components/Home';
import About from './Components/About';
import Contact from './Components/Contact';
import Navbar from './Components/Navbar';
import Dashboard from './Components/Dashboard';
import Profile from './Components/Profile';
import Settings from './Components/Settings';
import Student from './Components/Student';
import NotFound from './Components/NotFound';
import Login from './Components/Login';

const App = () => {
  return (
    <>
    <div>
      <Counter />
      <StudentForm />
      <Password />
      <ShoppingCart />
      <ComponentLoaded />
      <Timer />
      <DigitalClock />
      <FetchUsers />
      <TitleChanger />
      <ButtonClick />
      <InputField />
      <FormSubmit />
      <MouseEvents />
      <KeyBoardEvents />
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/student/:id" element={<Student />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/login" element={<Login />} />

        </Routes>
      </Router>
      
      <Theme />
      
    </div>
    </>
  );
}

export default App;

let btn = document.getElementById("button");

btn.addEventListener("click", function (event) {

    event.preventDefault();

    let data = {

        id: document.getElementById("id").value,
        item: document.getElementById("item").value,

    };

    fetch("http://127.0.0.1:3020/list/add/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
    });
});

fetch("http://127.0.0.1:3020/list/")
.then(response => response.json())
.then(result => {
    console.log(result);
});

let updateBtn = document.getElementById("updateButton");

updateBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let data = {

        item: document.getElementById("item").value,

    };

    let itemId = document.getElementById("id").value;

    fetch(`http://127.0.0.1:3020/list/update/${itemId}/`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
    });
});

let deleteBtn = document.getElementById("deleteButton");

deleteBtn.addEventListener("click", function (event) {

    event.preventDefault();

    let itemId = document.getElementById("id").value;

    fetch(`http://127.0.0.1:3020/list/delete/${itemId}/`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(result => {
        console.log(result);
    });
});

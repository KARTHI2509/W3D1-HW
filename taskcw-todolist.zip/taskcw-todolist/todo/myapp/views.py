import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .db import list as todo_collection  # Aliased to prevent any future name crashes


def get_list(request):
    if request.method == "GET":
        items = []  # FIX: Changed variable name from 'list' to 'items'

        # Fetch data using the MongoDB collection alias
        for i in todo_collection.find():
            i["_id"] = str(i["_id"])  # Convert ObjectId/string to safe JSON format
            items.append(i)

        return JsonResponse(items, safe=False)
    return JsonResponse({"error": "Invalid request method"}, status=405)


@csrf_exempt
def add_item(request):
    if request.method == "POST":
        data = json.loads(request.body)
        item = data.get("item")
        if item:
            # FIX: Use custom string ID fallback if your frontend sends an 'id'
            if "id" in data:
                payload = {"_id": str(data["id"]), "item": item}
            else:
                payload = {"item": item}

            todo_collection.insert_one(payload)
            return JsonResponse({"message": "Item added successfully"})
        return JsonResponse({"error": "Item is required"}, status=400)
    return JsonResponse({"error": "Invalid request method"}, status=405)


@csrf_exempt
def update_item(request, item_id):
    if request.method == "PUT":
        data = json.loads(request.body)
        new_item = data.get("item")
        if new_item:
            # FIX: Query matching the plain string item_id
            result = todo_collection.update_one(
                {"_id": str(item_id)}, {"$set": {"item": new_item}}
            )
            if result.modified_count > 0:
                return JsonResponse({"message": "Item updated successfully"})
            return JsonResponse({"error": "Item not found"}, status=404)
        return JsonResponse({"error": "New item is required"}, status=400)
    return JsonResponse({"error": "Invalid request method"}, status=405)


@csrf_exempt
def delete_item(request, item_id):
    if request.method == "DELETE":
        # FIX: Query matching the plain string item_id
        result = todo_collection.delete_one({"_id": str(item_id)})
        if result.deleted_count > 0:
            return JsonResponse({"message": "Item deleted successfully"})
        return JsonResponse({"error": "Item not found"}, status=404)
    return JsonResponse({"error": "Invalid request method"}, status=405)
